from flask import Flask, render_template, request, redirect, url_for, jsonify, make_response
from datetime import datetime, timedelta
import random
import string
import html
import os
from dotenv import load_dotenv
from auth import generate_token, token_required, verify_token, init_auth_routes
import auth
from werkzeug.utils import secure_filename
from flask_swagger_ui import get_swaggerui_blueprint
from flask_cors import CORS
from database import init_connection_pool, init_db, execute_query, execute_transaction
from ai_agent_deepseek import ai_agent
from transaction_graphql import transaction_graphql_schema
import time
from functools import wraps
from collections import defaultdict
import requests
from urllib.parse import urlparse
import platform

load_dotenv()

app = Flask(__name__)
CORS(app)

init_connection_pool()

SWAGGER_URL = '/api/partner/docs'
API_URL = '/static/openapi.json'

swaggerui_blueprint = get_swaggerui_blueprint(
    SWAGGER_URL,
    API_URL,
    config={
        'app_name': "MilliBank Partner API",
        'validatorUrl': None
    }
)

app.register_blueprint(swaggerui_blueprint, url_prefix=SWAGGER_URL)

app.secret_key = "secret123"

RATE_LIMIT_WINDOW = 3 * 60 * 60
UNAUTHENTICATED_LIMIT = 5
AUTHENTICATED_LIMIT = 10

rate_limit_storage = defaultdict(list)

CARD_CURRENCY_RATES = {
    'USD': {'rate': 1.0,        'symbol': '$',    'precision': 2},
    'GBP': {'rate': 0.79,       'symbol': '£',    'precision': 2},
    'AZN': {'rate': 1.70,       'symbol': '₼',    'precision': 2},
    'JPY': {'rate': 149.5,      'symbol': '¥',    'precision': 2},
    'EUR': {'rate': 0.92,       'symbol': '€',    'precision': 2},
    'TRY': {'rate': 32.5,       'symbol': '₺',    'precision': 2},
    'BTC': {'rate': 0.000014,   'symbol': 'BTC ', 'precision': 8},
    'ETH': {'rate': 0.0004,     'symbol': 'ETH ', 'precision': 8}
}

def normalize_card_currency(currency):
    normalized = str(currency or 'AZN').upper()
    return normalized if normalized in CARD_CURRENCY_RATES else 'AZN'

def convert_usd_to_card_currency(amount, currency):
    currency_code = normalize_card_currency(currency)
    rate_info = CARD_CURRENCY_RATES[currency_code]
    return round(float(amount) * rate_info['rate'], rate_info['precision'])

def cleanup_rate_limit_storage():
    current_time = time.time()
    cutoff_time = current_time - RATE_LIMIT_WINDOW
    for key in list(rate_limit_storage.keys()):
        rate_limit_storage[key] = [
            (timestamp, count) for timestamp, count in rate_limit_storage[key]
            if timestamp > cutoff_time
        ]
        if not rate_limit_storage[key]:
            del rate_limit_storage[key]

def get_client_ip():
    if request.headers.get('X-Forwarded-For'):
        return request.headers.get('X-Forwarded-For').split(',')[0].strip()
    elif request.headers.get('X-Real-IP'):
        return request.headers.get('X-Real-IP')
    else:
        return request.remote_addr

def check_rate_limit(key, limit):
    cleanup_rate_limit_storage()
    current_time = time.time()
    request_count = sum(count for timestamp, count in rate_limit_storage[key] if timestamp > current_time - RATE_LIMIT_WINDOW)
    if request_count >= limit:
        return False, request_count, limit
    rate_limit_storage[key].append((current_time, 1))
    return True, request_count + 1, limit

def ai_rate_limit(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        client_ip = get_client_ip()
        auth_header = request.headers.get('Authorization')
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
            try:
                user_data = verify_token(token)
                if user_data:
                    user_key = f"ai_auth_user_{user_data['user_id']}"
                    ip_key   = f"ai_auth_ip_{client_ip}"
                    user_allowed, user_count, user_limit = check_rate_limit(user_key, AUTHENTICATED_LIMIT)
                    if not user_allowed:
                        return jsonify({
                            'status': 'error',
                            'message': 'Too many requests. Please try again later.'
                        }), 429
                    ip_allowed, ip_count, ip_limit = check_rate_limit(ip_key, AUTHENTICATED_LIMIT)
                    if not ip_allowed:
                        return jsonify({
                            'status': 'error',
                            'message': 'Too many requests. Please try again later.'
                        }), 429
                    return f(*args, **kwargs)
            except:
                pass
        ip_key = f"ai_unauth_ip_{client_ip}"
        ip_allowed, ip_count, ip_limit = check_rate_limit(ip_key, UNAUTHENTICATED_LIMIT)
        if not ip_allowed:
            return jsonify({
                'status': 'error',
                'message': 'Too many requests. Please try again later.'
            }), 429
        return f(*args, **kwargs)
    return decorated_function

UPLOAD_FOLDER = 'static/uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def generate_account_number():
    return ''.join(random.choices(string.digits, k=10))

def generate_card_number():
    return ''.join(random.choices(string.digits, k=16))

def generate_cvv():
    return ''.join(random.choices(string.digits, k=3))

@app.after_request
def remove_info_headers(response):
    response.headers.pop('X-Powered-By', None)
    response.headers.pop('Server', None)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    return response

# --- GraphQL ---

@app.route('/api/v2/analytics/query', methods=['GET'])
def graphql_info():
    return jsonify({
        'message': 'Send authenticated POST requests to query transaction analytics.',
        'introspection': 'enabled'
    })

@app.route('/api/v2/analytics/query', methods=['POST'])
@token_required
def graphql_endpoint(current_user):
    payload = request.get_json(silent=True) or {}
    query    = payload.get('query', '')
    variables = payload.get('variables') or {}
    operation_name = payload.get('operationName')

    if not query:
        return jsonify({'errors': [{'message': 'A query is required.'}]}), 400

    result = transaction_graphql_schema.execute(
        query,
        variable_values=variables,
        operation_name=operation_name,
        context_value={'current_user': current_user}
    )

    response = {}
    status_code = 200
    if result.errors:
        response['errors'] = [{'message': str(e)} for e in result.errors]
        status_code = 400
    if result.data is not None:
        response['data'] = result.data
    return jsonify(response), status_code

# --- Public pages ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/privacy')
def privacy():
    return render_template('privacy.html')

@app.route('/terms')
def terms():
    return render_template('terms.html')

@app.route('/compliance')
def compliance():
    return render_template('compliance.html')

@app.route('/careers')
def careers():
    return render_template('careers.html')

@app.route('/blog')
def blog():
    return render_template('blog.html')

# --- Auth ---

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            user_data = request.get_json()
            account_number = generate_account_number()

            existing_user = execute_query(
                "SELECT username FROM users WHERE username = %s",
                (user_data.get('username'),)
            )
            if existing_user and existing_user[0]:
                return jsonify({
                    'status': 'error',
                    'message': 'Username already exists'
                }), 400

            fields = ['username', 'password', 'account_number']
            values = [user_data.get('username'), user_data.get('password'), account_number]

            for key, value in user_data.items():
                if key not in ['username', 'password']:
                    fields.append(key)
                    values.append(value)

            query = f"""
                INSERT INTO users ({', '.join(fields)})
                VALUES ({', '.join(['%s'] * len(fields))})
                RETURNING id, username, account_number, balance, is_admin
            """
            result = execute_query(query, values, fetch=True)

            if not result or not result[0]:
                raise Exception("Failed to create user")

            user = result[0]
            return jsonify({
                'status': 'success',
                'message': 'Registration successful. Please proceed to login.',
                'account_number': user[2]
            })

        except Exception as e:
            return jsonify({
                'status': 'error',
                'message': 'Internal Server Error'
            }), 500

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            data = request.get_json()
            username = data.get('username')
            password = data.get('password')
            suspension_message = 'Your account has been suspended. Please contact support or visit any MilliBank branch.'

            query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
            user = execute_query(query)

            if user and len(user) > 0:
                user = user[0]
                if len(user) > 9 and user[9]:
                    return jsonify({'status': 'error', 'message': suspension_message}), 403

                token = generate_token(user[0], user[1], user[5])
                response = make_response(jsonify({
                    'status': 'success',
                    'message': 'Login successful',
                    'token': token,
                    'accountNumber': user[3],
                    'isAdmin': user[5]
                }))
                response.set_cookie('token', token, httponly=True)
                return response

            return jsonify({'status': 'error', 'message': 'Invalid credentials'}), 401

        except Exception as e:
            return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

    return render_template('login.html')


@app.route('/dashboard')
@token_required
def dashboard(current_user):
    user = execute_query(
        "SELECT * FROM users WHERE id = %s",
        (current_user['user_id'],)
    )[0]

    loans = execute_query(
        "SELECT * FROM loans WHERE user_id = %s",
        (current_user['user_id'],)
    )

    user_data = {
        'id':              user[0],
        'username':        user[1],
        'account_number':  user[3],
        'balance':         float(user[4]),
        'is_admin':        user[5],
        'profile_picture': user[6] if len(user) > 6 and user[6] else 'user.png'
    }

    return render_template('dashboard.html',
                           user=user_data,
                           username=user[1],
                           balance=float(user[4]),
                           account_number=user[3],
                           loans=loans,
                           is_admin=current_user.get('is_admin', False))

# --- Account ---

@app.route('/api/v1/accounts/<account_number>/summary')
def check_balance(account_number):
    try:
        user = execute_query(
            f"SELECT username, balance FROM users WHERE account_number='{account_number}'"
        )
        if user:
            return jsonify({
                'status': 'success',
                'username': user[0][0],
                'balance': float(user[0][1]),
                'account_number': account_number
            })
        return jsonify({'status': 'error', 'message': 'Account not found'}), 404
    except Exception as e:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- Transfers ---

@app.route('/api/v1/payments/transfer', methods=['POST'])
@token_required
def transfer(current_user):
    try:
        data    = request.get_json()
        amount  = float(data.get('amount'))
        to_account = data.get('to_account')

        sender_data = execute_query(
            "SELECT account_number, balance FROM users WHERE id = %s",
            (current_user['user_id'],)
        )[0]

        from_account = sender_data[0]
        balance      = float(sender_data[1])

        if balance >= abs(amount):
            try:
                queries = [
                    ("UPDATE users SET balance = balance - %s WHERE id = %s",
                     (amount, current_user['user_id'])),
                    ("UPDATE users SET balance = balance + %s WHERE account_number = %s",
                     (amount, to_account)),
                    ("""INSERT INTO transactions
                           (from_account, to_account, amount, transaction_type, description)
                           VALUES (%s, %s, %s, %s, %s)""",
                     (from_account, to_account, amount, 'transfer', data.get('description', 'Transfer')))
                ]
                execute_transaction(queries)
                return jsonify({'status': 'success', 'message': 'Transfer completed', 'new_balance': balance - amount})
            except Exception:
                return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500
        else:
            return jsonify({'status': 'error', 'message': 'Insufficient funds'}), 400

    except Exception as e:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- Transaction History ---

@app.route('/api/v2/accounts/history')
def get_transaction_history():
    account_number = request.args.get('account')
    if not account_number:
        return jsonify({'status': 'error', 'message': 'Account parameter required'}), 400
    try:
        query = f"""
            SELECT id, from_account, to_account, amount, timestamp, transaction_type, description
            FROM transactions
            WHERE from_account='{account_number}' OR to_account='{account_number}'
            ORDER BY timestamp DESC
        """
        transactions = execute_query(query)
        transaction_list = [{
            'id':           t[0],
            'from_account': t[1],
            'to_account':   t[2],
            'amount':       float(t[3]),
            'timestamp':    str(t[4]),
            'type':         t[5],
            'description':  t[6]
        } for t in transactions]
        return jsonify({'status': 'success', 'account_number': account_number, 'transactions': transaction_list})
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- File Upload ---

@app.route('/api/v1/user/avatar', methods=['POST'])
@token_required
def upload_profile_picture(current_user):
    if 'profile_picture' not in request.files:
        return jsonify({'status': 'error', 'message': 'No file provided'}), 400

    file = request.files['profile_picture']
    if file.filename == '':
        return jsonify({'status': 'error', 'message': 'No file selected'}), 400

    try:
        filename  = secure_filename(file.filename)
        filename  = f"{random.randint(1, 1000000)}_{filename}"
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(file_path)

        execute_query(
            "UPDATE users SET profile_picture = %s WHERE id = %s",
            (filename, current_user['user_id']),
            fetch=False
        )
        return jsonify({'status': 'success', 'message': 'Profile picture updated successfully'})
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/user/media/sync', methods=['POST'])
@token_required
def upload_profile_picture_url(current_user):
    try:
        data      = request.get_json() or {}
        image_url = data.get('image_url')

        if not image_url:
            return jsonify({'status': 'error', 'message': 'image_url is required'}), 400

        resp = requests.get(image_url, timeout=10, allow_redirects=True, verify=False)
        if resp.status_code >= 400:
            return jsonify({'status': 'error', 'message': 'Failed to retrieve media resource'}), 400

        parsed   = urlparse(image_url)
        basename = os.path.basename(parsed.path) or 'avatar'
        filename  = secure_filename(basename)
        filename  = f"{random.randint(1, 1000000)}_{filename}"
        file_path = os.path.join(UPLOAD_FOLDER, filename)

        with open(file_path, 'wb') as f:
            f.write(resp.content)

        execute_query(
            "UPDATE users SET profile_picture = %s WHERE id = %s",
            (filename, current_user['user_id']),
            fetch=False
        )
        return jsonify({'status': 'success', 'message': 'Profile picture updated successfully',
                        'file_path': os.path.join('static/uploads', filename)})
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- Bio / XSS ---

@app.route('/api/v1/user/profile/update', methods=['POST'])
@token_required
def update_bio(current_user):
    try:
        data = request.get_json() or {}
        bio  = data.get('bio', '')
        execute_query(
            "UPDATE users SET bio = %s WHERE id = %s",
            (bio, current_user['user_id']),
            fetch=False
        )
        return jsonify({'status': 'success', 'message': 'Profile updated successfully', 'bio': bio})
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- Internal SSRF demo endpoints ---

def _is_loopback_request():
    try:
        ip = request.remote_addr or ''
        return ip == '127.0.0.1' or ip.startswith('127.') or ip == '::1'
    except Exception:
        return False

@app.route('/internal/secret', methods=['GET'])
def internal_secret():
    if not _is_loopback_request():
        return jsonify({'error': 'Forbidden'}), 403

    demo_env = {k: os.getenv(k) for k in [
        'DB_NAME', 'DB_USER', 'DB_PASSWORD', 'DB_HOST', 'DB_PORT', 'DEEPSEEK_API_KEY'
    ]}
    if demo_env.get('DEEPSEEK_API_KEY'):
        demo_env['DEEPSEEK_API_KEY'] = demo_env['DEEPSEEK_API_KEY'][:8] + '...'

    return jsonify({
        'status': 'internal',
        'secrets': {
            'app_secret_key':  app.secret_key,
            'jwt_secret':      getattr(auth, 'JWT_SECRET', None),
            'env_preview':     demo_env
        },
        'system': {
            'platform':       platform.platform(),
            'python_version': platform.python_version()
        }
    })

@app.route('/internal/config.json', methods=['GET'])
def internal_config():
    if not _is_loopback_request():
        return jsonify({'error': 'Forbidden'}), 403
    return jsonify({
        'app': {'name': 'MilliBank', 'debug': False, 'swagger_url': SWAGGER_URL},
        'rate_limits': {
            'window_seconds':        RATE_LIMIT_WINDOW,
            'unauthenticated_limit': UNAUTHENTICATED_LIMIT,
            'authenticated_limit':   AUTHENTICATED_LIMIT
        }
    })

@app.route('/latest/meta-data/', methods=['GET'])
def metadata_root():
    if not _is_loopback_request():
        return make_response('Forbidden', 403)
    body = '\n'.join(['ami-id', 'hostname', 'iam/', 'instance-id', 'local-ipv4', 'public-ipv4', 'security-groups']) + '\n'
    resp = make_response(body, 200)
    resp.mimetype = 'text/plain'
    return resp

@app.route('/latest/meta-data/ami-id')
def metadata_ami():
    if not _is_loopback_request(): return make_response('Forbidden', 403)
    return make_response('ami-0millibank1234\n', 200)

@app.route('/latest/meta-data/hostname')
def metadata_hostname():
    if not _is_loopback_request(): return make_response('Forbidden', 403)
    return make_response('millibank.internal\n', 200)

@app.route('/latest/meta-data/instance-id')
def metadata_instance():
    if not _is_loopback_request(): return make_response('Forbidden', 403)
    return make_response('i-0millibank1234\n', 200)

@app.route('/latest/meta-data/local-ipv4')
def metadata_local_ip():
    if not _is_loopback_request(): return make_response('Forbidden', 403)
    return make_response('127.0.0.1\n', 200)

@app.route('/latest/meta-data/public-ipv4')
def metadata_public_ip():
    if not _is_loopback_request(): return make_response('Forbidden', 403)
    return make_response('198.51.100.42\n', 200)

@app.route('/latest/meta-data/security-groups')
def metadata_sg():
    if not _is_loopback_request(): return make_response('Forbidden', 403)
    return make_response('default\n', 200)

@app.route('/latest/meta-data/iam/')
def metadata_iam_root():
    if not _is_loopback_request(): return make_response('Forbidden', 403)
    return make_response('security-credentials/\n', 200)

@app.route('/latest/meta-data/iam/security-credentials/')
def metadata_iam_list():
    if not _is_loopback_request(): return make_response('Forbidden', 403)
    return make_response('millibank-role\n', 200)

@app.route('/latest/meta-data/iam/security-credentials/millibank-role')
def metadata_iam_role():
    if not _is_loopback_request(): return jsonify({'error': 'Forbidden'}), 403
    creds = {
        'Code':            'Success',
        'LastUpdated':     datetime.now().isoformat(),
        'Type':            'AWS-HMAC',
        'AccessKeyId':     'ASIADEMO1234567890',
        'SecretAccessKey': 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYDEMODEMO',
        'Token':           'IQoJb3JpZ2luX2VjEJ//////////wEaCXVzLXdlc3QtMiJIMEYCIQCdemo',
        'Expiration':      (datetime.now() + timedelta(hours=1)).isoformat(),
        'RoleArn':         'arn:aws:iam::123456789012:role/millibank-role'
    }
    return jsonify(creds)

# --- Loans ---

@app.route('/api/v1/credit/apply', methods=['POST'])
@token_required
def request_loan(current_user):
    try:
        data   = request.get_json()
        amount = float(data.get('amount'))
        execute_query(
            "INSERT INTO loans (user_id, amount) VALUES (%s, %s)",
            (current_user['user_id'], amount),
            fetch=False
        )
        return jsonify({'status': 'success', 'message': 'Loan application submitted successfully'})
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- Admin ---

@app.route('/portal/sys-mgmt')
@token_required
def admin_panel(current_user):
    if not current_user['is_admin']:
        return render_template('login.html'), 403

    page     = max(request.args.get('page', default=1, type=int), 1)
    per_page = 10

    total_users  = execute_query("SELECT COUNT(*) FROM users")[0][0]
    total_pages  = max((total_users + per_page - 1) // per_page, 1)
    page         = min(page, total_pages)
    offset       = (page - 1) * per_page

    users = execute_query(
        "SELECT * FROM users ORDER BY id LIMIT %s OFFSET %s",
        (per_page, offset)
    )

    loan_page     = max(request.args.get('loan_page', default=1, type=int), 1)
    loan_per_page = 10
    total_pending = execute_query("SELECT COUNT(*) FROM loans WHERE status='pending'")[0][0]
    loan_total_pages = max((total_pending + loan_per_page - 1) // loan_per_page, 1)
    loan_page    = min(loan_page, loan_total_pages)
    loan_offset  = (loan_page - 1) * loan_per_page

    pending_loans = execute_query(
        "SELECT * FROM loans WHERE status='pending' ORDER BY id LIMIT %s OFFSET %s",
        (loan_per_page, loan_offset)
    )

    return render_template(
        'admin.html',
        users=users,
        pending_loans=pending_loans,
        page=page,
        total_pages=total_pages,
        total_users=total_users,
        per_page=per_page,
        loan_page=loan_page,
        loan_total_pages=loan_total_pages,
        total_pending_loans=total_pending,
        loan_per_page=loan_per_page
    )

@app.route('/portal/sys-mgmt/loans/<int:loan_id>/approve', methods=['POST'])
@token_required
def approve_loan(current_user, loan_id):
    if not current_user.get('is_admin'):
        return jsonify({'status': 'error', 'message': 'Access denied'}), 403
    try:
        loan = execute_query("SELECT * FROM loans WHERE id = %s", (loan_id,))[0]
        if loan:
            queries = [
                ("UPDATE loans SET status='approved' WHERE id = %s", (loan_id,)),
                ("UPDATE users SET balance = balance + %s WHERE id = %s", (float(loan[2]), loan[1]))
            ]
            execute_transaction(queries)
            return jsonify({'status': 'success', 'message': 'Loan approved successfully'})
        return jsonify({'status': 'error', 'message': 'Loan not found'}), 404
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/portal/sys-mgmt/accounts/<int:user_id>/delete', methods=['POST'])
@token_required
def delete_account(current_user, user_id):
    if not current_user.get('is_admin'):
        return jsonify({'status': 'error', 'message': 'Access denied'}), 403
    try:
        execute_query("DELETE FROM users WHERE id = %s", (user_id,), fetch=False)
        return jsonify({'status': 'success', 'message': 'Account removed successfully'})
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/portal/sys-mgmt/accounts/<int:user_id>/status', methods=['POST'])
@token_required
def toggle_account_suspension(current_user, user_id):
    if not current_user.get('is_admin'):
        return jsonify({'status': 'error', 'message': 'Access denied'}), 403
    try:
        if user_id == current_user.get('user_id'):
            return jsonify({'status': 'error', 'message': 'Cannot modify your own account status'}), 400

        user = execute_query(
            "SELECT id, username, is_suspended, is_admin FROM users WHERE id = %s", (user_id,)
        )
        if not user:
            return jsonify({'status': 'error', 'message': 'User not found'}), 404

        user       = user[0]
        new_status = not bool(user[2])
        execute_query("UPDATE users SET is_suspended = %s WHERE id = %s", (new_status, user_id), fetch=False)
        return jsonify({
            'status':  'success',
            'message': f"Account {'suspended' if new_status else 'reactivated'} successfully",
            'user': {'id': user_id, 'username': user[1], 'is_suspended': new_status}
        })
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/portal/sys-mgmt/operators/create', methods=['POST'])
@token_required
def create_admin(current_user):
    if not current_user.get('is_admin'):
        return jsonify({'status': 'error', 'message': 'Access denied'}), 403
    try:
        data           = request.get_json()
        username       = data.get('username')
        password       = data.get('password')
        account_number = generate_account_number()
        execute_query(
            f"INSERT INTO users (username, password, account_number, is_admin) VALUES ('{username}', '{password}', '{account_number}', true)",
            fetch=False
        )
        return jsonify({'status': 'success', 'message': 'Operator account created successfully'})
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- Password reset ---

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        try:
            data     = request.get_json()
            username = data.get('username')

            user = execute_query(f"SELECT id FROM users WHERE username='{username}'")
            if user:
                reset_pin = str(random.randint(100, 999))
                execute_query(
                    "UPDATE users SET reset_pin = %s WHERE username = %s",
                    (reset_pin, username),
                    fetch=False
                )
                return jsonify({'status': 'success', 'message': 'A reset PIN has been sent to your registered email.'})
            else:
                return jsonify({'status': 'error', 'message': 'User not found'}), 404
        except Exception:
            return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500
    return render_template('forgot_password.html')

@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':
        try:
            data         = request.get_json()
            username     = data.get('username')
            reset_pin    = data.get('reset_pin')
            new_password = data.get('new_password')

            user = execute_query(
                "SELECT id FROM users WHERE username = %s AND reset_pin = %s",
                (username, reset_pin)
            )
            if user:
                execute_query(
                    "UPDATE users SET password = %s, reset_pin = NULL WHERE username = %s",
                    (new_password, username),
                    fetch=False
                )
                return jsonify({'status': 'success', 'message': 'Password updated successfully'})
            else:
                return jsonify({'status': 'error', 'message': 'Invalid reset PIN'}), 400
        except Exception:
            return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500
    return render_template('reset_password.html')

# --- API versioned password reset ---

@app.route('/api/v1/auth/password/reset-request', methods=['POST'])
def api_v1_forgot_password():
    try:
        data     = request.get_json()
        username = data.get('username')
        user     = execute_query(f"SELECT id FROM users WHERE username='{username}'")
        if user:
            reset_pin = str(random.randint(100, 999))
            execute_query("UPDATE users SET reset_pin = %s WHERE username = %s", (reset_pin, username), fetch=False)
            return jsonify({
                'status':  'success',
                'message': 'Reset PIN sent to registered email.',
                'meta':    {'timestamp': str(datetime.now()), 'username': username, 'pin_length': len(reset_pin), 'pin': reset_pin}
            })
        return jsonify({'status': 'error', 'message': 'User not found'}), 404
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v2/auth/password/reset-request', methods=['POST'])
def api_v2_forgot_password():
    try:
        data     = request.get_json()
        username = data.get('username')
        user     = execute_query(f"SELECT id FROM users WHERE username='{username}'")
        if user:
            reset_pin = str(random.randint(100, 999))
            execute_query("UPDATE users SET reset_pin = %s WHERE username = %s", (reset_pin, username), fetch=False)
            return jsonify({
                'status':  'success',
                'message': 'Reset PIN sent to registered email.',
                'meta':    {'timestamp': str(datetime.now()), 'username': username}
            })
        return jsonify({'status': 'error', 'message': 'User not found'}), 404
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v3/auth/password/reset-request', methods=['POST'])
def api_v3_forgot_password():
    try:
        data     = request.get_json()
        username = data.get('username')
        user     = execute_query(f"SELECT id FROM users WHERE username='{username}'")
        if user:
            reset_pin = str(random.randint(1000, 9999))
            execute_query("UPDATE users SET reset_pin = %s WHERE username = %s", (reset_pin, username), fetch=False)
            return jsonify({'status': 'success', 'message': 'Reset PIN sent to registered email.'})
        return jsonify({'status': 'error', 'message': 'User not found'}), 404
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v3/users/<int:user_id>', methods=['GET'])
@token_required
def api_v3_get_user(current_user, user_id):
    try:
        user = execute_query("SELECT * FROM users WHERE id = %s", (user_id,))
        if user:
            u = user[0]
            return jsonify({
                'status': 'success',
                'user': {
                    'id':             u[0],
                    'username':       u[1],
                    'account_number': u[3],
                    'balance':        float(u[4]) if u[4] else 0,
                    'is_admin':       u[5],
                    'bio':            u[8] if len(u) > 8 else None
                }
            })
        return jsonify({'status': 'error', 'message': 'User not found'}), 404
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/auth/password/confirm-reset', methods=['POST'])
def api_v1_reset_password():
    try:
        data         = request.get_json()
        username     = data.get('username')
        reset_pin    = data.get('reset_pin')
        new_password = data.get('new_password')
        user         = execute_query("SELECT id FROM users WHERE username = %s AND reset_pin = %s", (username, reset_pin))
        if user:
            execute_query("UPDATE users SET password = %s, reset_pin = NULL WHERE username = %s", (new_password, username), fetch=False)
            return jsonify({
                'status':  'success',
                'message': 'Password updated successfully',
                'meta':    {'timestamp': str(datetime.now()), 'username': username, 'reset_pin_used': reset_pin}
            })
        return jsonify({'status': 'error', 'message': 'Invalid reset PIN'}), 400
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v2/auth/password/confirm-reset', methods=['POST'])
def api_v2_reset_password():
    try:
        data         = request.get_json()
        username     = data.get('username')
        reset_pin    = data.get('reset_pin')
        new_password = data.get('new_password')
        user         = execute_query("SELECT id FROM users WHERE username = %s AND reset_pin = %s", (username, reset_pin))
        if user:
            execute_query("UPDATE users SET password = %s, reset_pin = NULL WHERE username = %s", (new_password, username), fetch=False)
            return jsonify({'status': 'success', 'message': 'Password updated successfully'})
        return jsonify({'status': 'error', 'message': 'Invalid reset PIN'}), 400
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v3/auth/password/confirm-reset', methods=['POST'])
def api_v3_reset_password():
    try:
        data         = request.get_json()
        username     = data.get('username')
        reset_pin    = data.get('reset_pin')
        new_password = data.get('new_password')
        user         = execute_query("SELECT id FROM users WHERE username = %s AND reset_pin = %s", (username, reset_pin))
        if user:
            execute_query("UPDATE users SET password = %s, reset_pin = NULL WHERE username = %s", (new_password, username), fetch=False)
            return jsonify({'status': 'success', 'message': 'Password updated successfully'})
        return jsonify({'status': 'error', 'message': 'Invalid reset PIN'}), 400
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- Transactions API ---

@app.route('/api/v1/accounts/transactions', methods=['GET'])
@token_required
def api_transactions(current_user):
    account_number = request.args.get('account_number')
    if not account_number:
        return jsonify({'status': 'error', 'message': 'account_number parameter required'}), 400
    query = f"""
        SELECT * FROM transactions
        WHERE from_account='{account_number}' OR to_account='{account_number}'
        ORDER BY timestamp DESC
    """
    try:
        transactions   = execute_query(query)
        transaction_list = [{
            'id':               t[0],
            'from_account':     t[1],
            'to_account':       t[2],
            'amount':           float(t[3]),
            'timestamp':        str(t[4]),
            'transaction_type': t[5],
            'description':      t[6]
        } for t in transactions]
        return jsonify({'transactions': transaction_list, 'account_number': account_number})
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- Virtual Cards ---

@app.route('/api/v1/cards/virtual/issue', methods=['POST'])
@token_required
def create_virtual_card(current_user):
    try:
        data        = request.get_json()
        card_limit  = float(data.get('card_limit', 1000.0))
        card_number = generate_card_number()
        cvv         = generate_cvv()
        expiry_date = (datetime.now() + timedelta(days=365)).strftime('%m/%y')
        card_type   = data.get('card_type', 'standard')
        card_currency = normalize_card_currency(data.get('currency'))

        query = f"""
            INSERT INTO virtual_cards
            (user_id, card_number, cvv, expiry_date, card_limit, card_type, currency)
            VALUES
            ({current_user['user_id']}, '{card_number}', '{cvv}', '{expiry_date}', {card_limit}, '{card_type}', '{card_currency}')
            RETURNING id
        """
        result = execute_query(query)
        if result:
            return jsonify({
                'status':  'success',
                'message': 'Virtual card issued successfully',
                'card_details': {
                    'id':              result[0][0],
                    'card_number':     card_number,
                    'cvv':             cvv,
                    'expiry_date':     expiry_date,
                    'limit':           card_limit,
                    'balance':         0,
                    'type':            card_type,
                    'currency':        card_currency,
                    'currency_symbol': CARD_CURRENCY_RATES[card_currency]['symbol']
                }
            })
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/cards/virtual', methods=['GET'])
@token_required
def get_virtual_cards(current_user):
    try:
        query = f"""
            SELECT id, card_number, cvv, expiry_date, card_limit, current_balance,
                   is_frozen, is_active, created_at, last_used_at, card_type, currency
            FROM virtual_cards
            WHERE user_id = {current_user['user_id']}
        """
        cards = execute_query(query)
        return jsonify({
            'status': 'success',
            'cards': [{
                'id':              card[0],
                'card_number':     card[1],
                'cvv':             card[2],
                'expiry_date':     card[3],
                'limit':           float(card[4]),
                'balance':         float(card[5]),
                'is_frozen':       card[6],
                'is_active':       card[7],
                'created_at':      str(card[8]),
                'last_used_at':    str(card[9]) if card[9] else None,
                'card_type':       card[10],
                'currency':        card[11],
                'currency_symbol': CARD_CURRENCY_RATES[normalize_card_currency(card[11])]['symbol']
            } for card in cards]
        })
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/cards/virtual/<int:card_id>/freeze', methods=['POST'])
@token_required
def toggle_card_freeze(current_user, card_id):
    try:
        query = f"""
            UPDATE virtual_cards SET is_frozen = NOT is_frozen
            WHERE id = {card_id}
            RETURNING is_frozen
        """
        result = execute_query(query)
        if result:
            return jsonify({'status': 'success', 'message': f"Card {'frozen' if result[0][0] else 'unfrozen'} successfully"})
        return jsonify({'status': 'error', 'message': 'Card not found'}), 404
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/cards/virtual/<int:card_id>/transactions', methods=['GET'])
@token_required
def get_card_transactions(current_user, card_id):
    try:
        query = f"""
            SELECT ct.*, vc.card_number, vc.currency
            FROM card_transactions ct
            JOIN virtual_cards vc ON ct.card_id = vc.id
            WHERE ct.card_id = {card_id}
            ORDER BY ct.timestamp DESC
        """
        transactions = execute_query(query)
        return jsonify({
            'status': 'success',
            'transactions': [{
                'id':          t[0],
                'amount':      float(t[2]),
                'merchant':    t[3],
                'type':        t[4],
                'status':      t[5],
                'timestamp':   str(t[6]),
                'description': t[7],
                'card_number': t[8],
                'currency':    t[9]
            } for t in transactions]
        })
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/cards/virtual/<int:card_id>/settings', methods=['POST'])
@token_required
def update_card_limit(current_user, card_id):
    try:
        data          = request.get_json()
        update_fields = []
        update_values = []
        updated_fields_list = []

        for key, value in data.items():
            try:
                value = float(value)
            except (ValueError, TypeError):
                value = str(value)
            update_fields.append(f"{key} = %s")
            update_values.append(value)
            updated_fields_list.append(key)

        query = f"""
            UPDATE virtual_cards
            SET {', '.join(update_fields)}
            WHERE id = {card_id}
            RETURNING id, card_limit, current_balance, is_frozen, is_active, card_type, currency
        """
        result = execute_query(query, tuple(update_values))
        if result:
            return jsonify({
                'status':  'success',
                'message': 'Card settings updated',
                'card': {
                    'id':              result[0][0],
                    'card_limit':      float(result[0][1]),
                    'current_balance': float(result[0][2]),
                    'is_frozen':       result[0][3],
                    'is_active':       result[0][4],
                    'card_type':       result[0][5],
                    'currency':        result[0][6]
                }
            })
        return jsonify({'status': 'error', 'message': 'Card not found'}), 404
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/cards/virtual/<int:card_id>/topup', methods=['POST'])
@token_required
def fund_virtual_card(current_user, card_id):
    try:
        data = request.get_json() or {}

        user_result = execute_query(
            "SELECT account_number, balance FROM users WHERE id = %s",
            (current_user['user_id'],)
        )
        card_result = execute_query(
            "SELECT id, user_id, card_number, card_limit, current_balance, is_frozen, currency, card_type FROM virtual_cards WHERE id = %s",
            (card_id,)
        )

        if not user_result or not card_result:
            return jsonify({'status': 'error', 'message': 'Card or account not found'}), 404

        user_account_number, user_balance = user_result[0]
        card          = card_result[0]
        card_currency = normalize_card_currency(card[6])
        funding_ctx   = {
            'amount':        data.get('amount', 0),
            'exchange_rate': CARD_CURRENCY_RATES[card_currency]['rate']
        }

        for key, value in data.items():
            funding_ctx[key] = value

        usd_amount    = float(funding_ctx.get('amount', 0))
        exchange_rate = float(funding_ctx.get('exchange_rate'))

        if usd_amount <= 0:
            return jsonify({'status': 'error', 'message': 'Amount must be greater than zero'}), 400
        if card[5]:
            return jsonify({'status': 'error', 'message': 'Card is frozen'}), 400
        if usd_amount > float(user_balance):
            return jsonify({'status': 'error', 'message': 'Insufficient main balance'}), 400

        converted_amount  = round(usd_amount * exchange_rate, CARD_CURRENCY_RATES[card_currency]['precision'])
        new_card_balance  = float(card[4]) + converted_amount

        if new_card_balance > float(card[3]):
            return jsonify({'status': 'error', 'message': 'Top-up would exceed card limit'}), 400

        funding_description = f"Topped up {card_currency} virtual card from main balance"
        queries = [
            ("UPDATE users SET balance = balance - %s WHERE id = %s", (usd_amount, current_user['user_id'])),
            ("UPDATE virtual_cards SET current_balance = current_balance + %s, last_used_at = CURRENT_TIMESTAMP WHERE id = %s", (converted_amount, card_id)),
            ("INSERT INTO card_transactions (card_id, amount, merchant_name, transaction_type, status, description) VALUES (%s, %s, %s, %s, %s, %s)",
             (card_id, converted_amount, 'Main Balance', 'funding', 'completed', funding_description)),
            ("INSERT INTO transactions (from_account, to_account, amount, transaction_type, description) VALUES (%s, %s, %s, %s, %s)",
             (user_account_number, card[2], usd_amount, 'virtual_card_funding',
              f"{funding_description}: ${usd_amount:.2f} @ {exchange_rate} -> {CARD_CURRENCY_RATES[card_currency]['symbol']}{converted_amount}"))
        ]
        execute_transaction(queries)

        return jsonify({
            'status':  'success',
            'message': 'Card topped up successfully',
            'funding': {
                'card_id':            card_id,
                'card_currency':      card_currency,
                'usd_amount':         round(usd_amount, 2),
                'converted_amount':   converted_amount,
                'exchange_rate':      exchange_rate,
                'main_balance_after': round(float(user_balance) - usd_amount, 2),
                'card_balance_after': new_card_balance
            }
        })
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- Bill Payments ---

@app.route('/api/v1/payments/bill-categories', methods=['GET'])
def get_bill_categories():
    try:
        categories = execute_query("SELECT * FROM bill_categories WHERE is_active = TRUE")
        return jsonify({
            'status': 'success',
            'categories': [{'id': c[0], 'name': c[1], 'description': c[2]} for c in categories]
        })
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/payments/providers/<int:category_id>', methods=['GET'])
def get_billers_by_category(category_id):
    try:
        query = f"""
            SELECT * FROM billers
            WHERE category_id = {category_id} AND is_active = TRUE
        """
        billers = execute_query(query)
        return jsonify({
            'status': 'success',
            'billers': [{
                'id':             b[0],
                'name':           b[2],
                'account_number': b[3],
                'description':    b[4],
                'minimum_amount': float(b[5]),
                'maximum_amount': float(b[6]) if b[6] else None
            } for b in billers]
        })
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/payments/bills/pay', methods=['POST'])
@token_required
def create_bill_payment(current_user):
    try:
        data           = request.get_json()
        biller_id      = data.get('biller_id')
        amount         = float(data.get('amount'))
        payment_method = data.get('payment_method')
        card_id        = data.get('card_id') if payment_method == 'virtual_card' else None

        payer_query  = f"SELECT id, username, account_number, balance FROM users WHERE id = {current_user['user_id']}"
        biller_query = f"""
            SELECT b.account_number, b.name, bc.name
            FROM billers b
            JOIN bill_categories bc ON b.category_id = bc.id
            WHERE b.id = {biller_id}
        """
        payer  = execute_query(payer_query)
        biller = execute_query(biller_query)

        if not payer or not biller:
            return jsonify({'status': 'error', 'message': 'Biller or account not found'}), 404

        payer  = payer[0]
        biller = biller[0]
        payer_account_number  = payer[2]
        payer_balance         = float(payer[3])
        biller_account_number = biller[0]
        biller_name           = biller[1]
        category_name         = biller[2]

        if payment_method == 'virtual_card' and card_id:
            card_query = f"SELECT current_balance, card_limit, is_frozen FROM virtual_cards WHERE id = {card_id}"
            card       = execute_query(card_query)[0]
            if card[2]:
                return jsonify({'status': 'error', 'message': 'Card is frozen'}), 400
            if amount > float(card[0]):
                return jsonify({'status': 'error', 'message': 'Insufficient card balance'}), 400
        elif payment_method == 'balance':
            if amount > payer_balance:
                return jsonify({'status': 'error', 'message': 'Insufficient balance'}), 400

        reference = f"MB{int(time.time())}"
        queries   = []

        queries.append((
            "INSERT INTO bill_payments (user_id, biller_id, amount, payment_method, card_id, reference_number, description) VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING id",
            (current_user['user_id'], biller_id, amount, payment_method, card_id, reference, data.get('description', 'Bill Payment'))
        ))
        queries.append((
            "INSERT INTO transactions (from_account, to_account, amount, transaction_type, description) VALUES (%s, %s, %s, %s, %s)",
            (payer_account_number, biller_account_number, amount, category_name,
             data.get('description') or f"{category_name} payment to {biller_name}")
        ))
        if payment_method == 'virtual_card':
            queries.append(("UPDATE virtual_cards SET current_balance = current_balance - %s WHERE id = %s", (amount, card_id)))
        else:
            queries.append(("UPDATE users SET balance = balance - %s WHERE id = %s", (amount, current_user['user_id'])))

        execute_transaction(queries)
        return jsonify({
            'status':  'success',
            'message': 'Payment processed successfully',
            'reference': reference
        })
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/payments/bills/history', methods=['GET'])
@token_required
def get_payment_history(current_user):
    try:
        query = f"""
            SELECT bp.*, b.name, bc.name, vc.card_number
            FROM bill_payments bp
            JOIN billers b ON bp.biller_id = b.id
            JOIN bill_categories bc ON b.category_id = bc.id
            LEFT JOIN virtual_cards vc ON bp.card_id = vc.id
            WHERE bp.user_id = {current_user['user_id']}
            ORDER BY bp.created_at DESC
        """
        payments = execute_query(query)
        return jsonify({
            'status': 'success',
            'payments': [{
                'id':            p[0],
                'amount':        float(p[3]),
                'payment_method': p[4],
                'card_number':   p[13] if p[13] else None,
                'reference':     p[6],
                'status':        p[7],
                'created_at':    str(p[8]),
                'processed_at':  str(p[9]) if p[9] else None,
                'description':   p[10],
                'biller_name':   p[11],
                'category_name': p[12]
            } for p in payments]
        })
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

# --- AI Support ---

@app.route('/api/v1/support/chat', methods=['POST'])
@ai_rate_limit
@token_required
def ai_chat_authenticated(current_user):
    try:
        data         = request.get_json()
        user_message = data.get('message', '')
        if not user_message:
            return jsonify({'status': 'error', 'message': 'Message is required'}), 400

        fresh_user_data = execute_query(
            "SELECT id, username, account_number, balance, is_admin, profile_picture FROM users WHERE id = %s",
            (current_user['user_id'],),
            fetch=True
        )
        if fresh_user_data:
            u = fresh_user_data[0]
            user_context = {
                'user_id':         u[0],
                'username':        u[1],
                'account_number':  u[2],
                'balance':         float(u[3]) if u[3] else 0.0,
                'is_admin':        bool(u[4]),
                'profile_picture': u[5]
            }
        else:
            user_context = {
                'user_id':        current_user['user_id'],
                'username':       current_user['username'],
                'account_number': current_user.get('account_number'),
                'is_admin':       current_user.get('is_admin', False),
                'balance':        0.0,
                'profile_picture': None
            }

        response = ai_agent.chat(user_message, user_context)
        return jsonify({'status': 'success', 'response': response, 'mode': 'authenticated'})

    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/support/chat/guest', methods=['POST'])
@ai_rate_limit
def ai_chat_anonymous():
    try:
        data         = request.get_json()
        user_message = data.get('message', '')
        if not user_message:
            return jsonify({'status': 'error', 'message': 'Message is required'}), 400
        response = ai_agent.chat(user_message, None)
        return jsonify({'status': 'success', 'response': response, 'mode': 'guest'})
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/support/status', methods=['GET'])
@ai_rate_limit
def ai_system_info():
    try:
        return jsonify({
            'status':  'success',
            'service': 'MilliBank AI Support',
            'available': True
        })
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500

@app.route('/api/v1/support/quota', methods=['GET'])
def ai_rate_limit_status():
    try:
        cleanup_rate_limit_storage()
        client_ip    = get_client_ip()
        current_time = time.time()

        unauth_key   = f"ai_unauth_ip_{client_ip}"
        unauth_count = sum(count for ts, count in rate_limit_storage[unauth_key]
                          if ts > current_time - RATE_LIMIT_WINDOW)

        return jsonify({
            'status': 'success',
            'quota': {
                'used':      unauth_count,
                'limit':     UNAUTHENTICATED_LIMIT,
                'remaining': max(0, UNAUTHENTICATED_LIMIT - unauth_count)
            }
        })
    except Exception:
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500


if __name__ == '__main__':
    init_db()
    init_auth_routes(app)
    app.run(host='0.0.0.0', port=5000, debug=False)
