<!-- src/views/partials/footer.php -->
<footer class="site-footer">
    <div class="footer-top">
        <div class="container footer-grid">
            <div class="footer-brand">
                <div class="footer-logo">
                    <span>🎓</span>
                    <div>
                        <strong>Code Academy University</strong>
                        <small>Est. 1965</small>
                    </div>
                </div>
                <p>Shaping tomorrow's technology leaders through excellence in education, research, and innovation.</p>
                <div class="social-links">
                    <a href="#" aria-label="Twitter">𝕏</a>
                    <a href="#" aria-label="LinkedIn">in</a>
                    <a href="#" aria-label="YouTube">▶</a>
                    <a href="#" aria-label="Instagram">◉</a>
                </div>
            </div>
            <div class="footer-links">
                <h4>Academics</h4>
                <ul>
                    <li><a href="/courses.php">Course Catalog</a></li>
                    <li><a href="/courses.php?dept=CS">Computer Science</a></li>
                    <li><a href="/courses.php?dept=SEC">Cybersecurity</a></li>
                    <li><a href="/courses.php?dept=DS">Data Science</a></li>
                    <li><a href="/courses.php?dept=SE">Software Engineering</a></li>
                </ul>
            </div>
            <div class="footer-links">
                <h4>Campus Life</h4>
                <ul>
                    <li><a href="/admissions.php">Admissions</a></li>
                    <li><a href="/about.php">About Us</a></li>
                    <li><a href="/contact.php">Contact</a></li>
                    <li><a href="/portal/dashboard.php">Student Portal</a></li>
                    <li><a href="#">Campus Map</a></li>
                </ul>
            </div>
            <div class="footer-contact">
                <h4>Get In Touch</h4>
                <address>
                    <p>📍 100 University Drive<br>Campus Town, CT 06001</p>
                    <p>📞 <a href="tel:+18005551234">(800) 555-1234</a></p>
                    <p>✉️ <a href="mailto:info@cau.edu">info@cau.edu</a></p>
                </address>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <p>© <?php echo date('Y'); ?> Code Academy University. All Rights Reserved.</p>
            <div class="footer-bottom-links">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Use</a>
                <a href="#">Accessibility</a>
                <a href="#">Sitemap</a>
            </div>
        </div>
    </div>
</footer>
