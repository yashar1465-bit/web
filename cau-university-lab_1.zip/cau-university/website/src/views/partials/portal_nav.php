<?php
// src/views/partials/portal_nav.php
?>
<header class="portal-header-bar">
    <nav class="portal-navbar">
        <a href="/" class="portal-brand">
            <span>🎓</span>
            <div>
                <strong>Code Academy University</strong>
                <small>Student Portal</small>
            </div>
        </a>
        <div class="portal-nav-right">
            <a href="/portal/messages.php" class="portal-nav-icon" title="Messages">💬</a>
            <a href="/portal/profile.php" class="portal-nav-icon" title="Profile">👤</a>
            <div class="portal-user-menu">
                <span class="portal-username"><?php echo htmlspecialchars($_SESSION['full_name'] ?? ''); ?></span>
                <a href="/auth/logout.php" class="btn btn-outline-sm">Sign Out</a>
            </div>
        </div>
    </nav>
</header>
