<?php
// src/views/partials/portal_sidebar.php
$currentFile = basename($_SERVER['PHP_SELF'], '.php');
?>
<aside class="portal-sidebar">
    <nav class="sidebar-nav">
        <div class="sidebar-section">
            <span class="sidebar-section-label">Main</span>
            <ul>
                <li>
                    <a href="/portal/dashboard.php" class="<?= $currentFile === 'dashboard' ? 'active' : '' ?>">
                        <span class="sidebar-icon">🏠</span> Dashboard
                    </a>
                </li>
                <li>
                    <a href="/portal/profile.php" class="<?= $currentFile === 'profile' ? 'active' : '' ?>">
                        <span class="sidebar-icon">👤</span> My Profile
                    </a>
                </li>
            </ul>
        </div>
        <div class="sidebar-section">
            <span class="sidebar-section-label">Academics</span>
            <ul>
                <li>
                    <a href="/portal/courses.php" class="<?= $currentFile === 'courses' ? 'active' : '' ?>">
                        <span class="sidebar-icon">📚</span> My Courses
                    </a>
                </li>
                <li>
                    <a href="/portal/grades.php" class="<?= $currentFile === 'grades' ? 'active' : '' ?>">
                        <span class="sidebar-icon">📊</span> Grades
                    </a>
                </li>
                <li>
                    <a href="/portal/register.php" class="<?= $currentFile === 'register' ? 'active' : '' ?>">
                        <span class="sidebar-icon">➕</span> Register
                    </a>
                </li>
            </ul>
        </div>
        <div class="sidebar-section">
            <span class="sidebar-section-label">Communication</span>
            <ul>
                <li>
                    <a href="/portal/messages.php" class="<?= $currentFile === 'messages' ? 'active' : '' ?>">
                        <span class="sidebar-icon">💬</span> Messages
                    </a>
                </li>
            </ul>
        </div>
        <?php if ($_SESSION['role'] === 'admin'): ?>
        <div class="sidebar-section">
            <span class="sidebar-section-label">Admin</span>
            <ul>
                <li>
                    <a href="/portal/admin.php">
                        <span class="sidebar-icon">⚙️</span> Admin Panel
                    </a>
                </li>
            </ul>
        </div>
        <?php endif; ?>
        <div class="sidebar-section">
            <span class="sidebar-section-label">System</span>
            <ul>
                <li>
                    <a href="/portal/api-demo.php">
                        <span class="sidebar-icon">🔌</span> API Explorer
                    </a>
                </li>
                <li>
                    <a href="/auth/logout.php">
                        <span class="sidebar-icon">🚪</span> Sign Out
                    </a>
                </li>
            </ul>
        </div>
    </nav>
</aside>
