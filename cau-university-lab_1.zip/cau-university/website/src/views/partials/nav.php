<?php
// src/views/partials/nav.php
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$isLoggedIn  = isLoggedIn();
?>
<header class="site-header" id="site-header">
    <nav class="navbar">
        <div class="nav-brand">
            <a href="/">
                <span class="brand-icon">🎓</span>
                <div class="brand-text">
                    <span class="brand-name">Code Academy</span>
                    <span class="brand-sub">University</span>
                </div>
            </a>
        </div>

        <ul class="nav-links">
            <li><a href="/" class="<?= $currentPage === 'index' ? 'active' : '' ?>">Home</a></li>
            <li><a href="/about.php" class="<?= $currentPage === 'about' ? 'active' : '' ?>">About</a></li>
            <li class="has-dropdown">
                <a href="/courses.php" class="<?= $currentPage === 'courses' ? 'active' : '' ?>">Academics ▾</a>
                <ul class="dropdown">
                    <li><a href="/courses.php">All Courses</a></li>
                    <li><a href="/courses.php?dept=CS">Computer Science</a></li>
                    <li><a href="/courses.php?dept=SEC">Cybersecurity</a></li>
                    <li><a href="/courses.php?dept=DS">Data Science</a></li>
                    <li><a href="/courses.php?dept=SE">Software Engineering</a></li>
                </ul>
            </li>
            <li><a href="/admissions.php" class="<?= $currentPage === 'admissions' ? 'active' : '' ?>">Admissions</a></li>
            <li><a href="/contact.php" class="<?= $currentPage === 'contact' ? 'active' : '' ?>">Contact</a></li>
        </ul>

        <div class="nav-actions">
            <?php if ($isLoggedIn): ?>
                <a href="/portal/dashboard.php" class="btn btn-portal">
                    <span class="portal-icon">👤</span>
                    <?php echo htmlspecialchars($_SESSION['full_name']); ?>
                </a>
                <a href="/auth/logout.php" class="btn btn-outline-sm">Sign Out</a>
            <?php else: ?>
                <a href="/auth/login.php" class="btn btn-outline-sm">Student Login</a>
                <a href="/admissions.php" class="btn btn-primary-sm">Apply Now</a>
            <?php endif; ?>
        </div>

        <button class="mobile-menu-toggle" id="mobileMenuToggle" aria-label="Menu">
            <span></span><span></span><span></span>
        </button>
    </nav>
</header>
