<?php
/**
 * Authentication & Session Helper
 * Code Academy University
 */

require_once __DIR__ . '/database.php';

// [VULNERABILITY: A07 - Identification and Authentication Failures]
// Session configuration with weak settings
ini_set('session.cookie_httponly', 0);   // [VULNERABILITY: A07] HttpOnly flag NOT set → JS can read cookie
ini_set('session.cookie_secure', 0);     // [VULNERABILITY: A07] Secure flag NOT set → sent over HTTP
ini_set('session.use_strict_mode', 0);   // [VULNERABILITY: A07] Session fixation possible
session_name('UNIVERSITY_SESS');
session_start();

/**
 * [VULNERABILITY: A07 - Weak Session Token Generation]
 * Uses MD5 of username + timestamp — predictable and weak
 */
function generateSessionToken($username) {
    return md5($username . time()); // [VULNERABILITY: A07] Predictable token
}

/**
 * [VULNERABILITY: A03 - SQL Injection in Login]
 * Login function using raw string concatenation — vulnerable to SQLi
 */
function loginUser($username, $password) {
    $conn = getMysqli();

    // [VULNERABILITY: A03 - SQL Injection]
    // Input is directly concatenated into the query — no prepared statements
    // Exploit: username = ' OR '1'='1' --
    //          password = anything
    $hashedPassword = md5($password); // [VULNERABILITY: A07] MD5 with no salt
    $query = "SELECT * FROM users WHERE username = '$username' AND password = '$hashedPassword'";

    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['username']  = $user['username'];
        $_SESSION['role']      = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];

        // [VULNERABILITY: A07] Token stored in DB but never invalidated on logout properly
        $token = generateSessionToken($username);
        $_SESSION['token'] = $token;

        $db = getDB();
        $stmt = $db->prepare("INSERT INTO sessions (user_id, token) VALUES (?, ?)");
        $stmt->execute([$user['id'], $token]);

        return $user;
    }

    return false;
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /auth/login.php');
        exit;
    }
}

function requireRole($role) {
    requireLogin();
    if ($_SESSION['role'] !== $role && $_SESSION['role'] !== 'admin') {
        // [VULNERABILITY: A01 - Broken Access Control]
        // Role check only on "admin" bypass — teachers can be confused with students
        header('Location: /portal/dashboard.php?error=unauthorized');
        exit;
    }
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function logout() {
    // [VULNERABILITY: A07] Session not properly invalidated — token persists in DB
    session_unset();
    session_destroy();
    // Missing: DELETE FROM sessions WHERE token = ?
    header('Location: /auth/login.php');
    exit;
}
