<?php
/**
 * Database Configuration
 * Code Academy University - Information Portal
 *
 * [VULNERABILITY: A05 - Security Misconfiguration]
 * Credentials hardcoded directly in source file (should use env vars with secrets manager)
 */

define('DB_HOST', getenv('DB_HOST') ?: 'db');
define('DB_NAME', getenv('DB_NAME') ?: 'university_db');
define('DB_USER', getenv('DB_USER') ?: 'root');      // [VULNERABILITY: A05] Default root user
define('DB_PASS', getenv('DB_PASS') ?: 'root');      // [VULNERABILITY: A05] Default weak password
define('API_URL', getenv('API_URL') ?: 'http://api:5000');
define('APP_DEBUG', getenv('APP_DEBUG') === 'true'); // [VULNERABILITY: A05] Debug mode exposes errors
define('APP_SECRET', getenv('APP_SECRET') ?: 'secret123'); // [VULNERABILITY: A07] Weak secret

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                // [VULNERABILITY: A05] Error messages exposed to user when APP_DEBUG is true
            ]);
        } catch (PDOException $e) {
            if (APP_DEBUG) {
                // [VULNERABILITY: A05] Full exception including credentials context shown in debug mode
                die("Database connection failed: " . $e->getMessage());
            }
            die("Service temporarily unavailable.");
        }
    }
    return $pdo;
}

function getMysqli() {
    // [VULNERABILITY: A03 - SQLi] Raw mysqli connection used in vulnerable query functions
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        if (APP_DEBUG) {
            die("Connection failed: " . $conn->connect_error);
        }
        die("Service unavailable.");
    }
    return $conn;
}
