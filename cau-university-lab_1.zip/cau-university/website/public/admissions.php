<?php require_once __DIR__ . '/../src/config/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admissions | Code Academy University</title>
    <link rel="stylesheet" href="/css/main.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/../src/views/partials/nav.php'; ?>
<div class="page-hero small">
    <div class="container">
        <h1>Admissions</h1>
        <p>Your journey to Code Academy University starts here. Fall 2025 applications are now open.</p>
    </div>
</div>
<div class="container admissions-page">
    <div class="admissions-grid">
        <div>
            <h2 style="margin-bottom:24px;">Admission Requirements</h2>
            <ul class="requirements-list">
                <?php foreach ([
                    'Completed secondary school or equivalent with minimum 3.0 GPA',
                    'Official transcripts from all previously attended institutions',
                    'SAT (1200+ recommended) or ACT (26+ recommended) scores',
                    'Two letters of recommendation from teachers or counselors',
                    'Personal statement (500–750 words)',
                    'Resume or CV highlighting academic and extracurricular achievements',
                    'Application fee of $65 (waivers available)',
                    'TOEFL score of 90+ or IELTS 7.0+ for international applicants',
                ] as $req): ?>
                <li><span class="req-check">✓</span> <?= htmlspecialchars($req) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div>
            <div class="deadline-card">
                <h3>Application Deadlines</h3>
                <?php foreach ([
                    ['Early Decision','November 1, 2024'],
                    ['Early Action','December 1, 2024'],
                    ['Regular Decision','February 1, 2025'],
                    ['Transfer Students','March 15, 2025'],
                    ['International','January 15, 2025'],
                ] as [$type,$date]): ?>
                <div class="deadline-item">
                    <span><?= htmlspecialchars($type) ?></span>
                    <span class="deadline-date"><?= htmlspecialchars($date) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <div style="background:var(--white);border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:28px;">
                <h3 style="margin-bottom:16px;">Ready to Apply?</h3>
                <p style="color:var(--gray-600);margin-bottom:20px;font-size:.92rem;">Start your application today. The process takes about 45 minutes.</p>
                <a href="/contact.php" class="btn btn-primary btn-full">Start Application</a>
                <a href="/contact.php" class="btn btn-outline-sm btn-full" style="margin-top:10px;">Request Information</a>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../src/views/partials/footer.php'; ?>
</body>
</html>
