<?php
// public/search.php
// [VULNERABILITY: A03 - SQL Injection in search]
// The search query is concatenated directly into SQL — classic SQLi

require_once __DIR__ . '/../src/config/auth.php';
$conn = getMysqli();

// [VULNERABILITY: A03 - Reflected XSS + SQL Injection]
// 'q' parameter used in both SQL query AND HTML output without sanitization
$query   = $_GET['q']    ?? '';
$type    = $_GET['type'] ?? 'all';

$courses  = [];
$faculty  = [];
$students = [];

if (!empty($query)) {
    if ($type === 'all' || $type === 'courses') {
        // [VULNERABILITY: A03 - SQL Injection]
        // Direct string concatenation — no prepared statement
        // Exploit: q=' UNION SELECT 1,username,password,email,5,6,7,8 FROM users --
        $sql = "SELECT id, code, name, description, credits, semester
                FROM courses
                WHERE name LIKE '%$query%'
                   OR code LIKE '%$query%'
                   OR description LIKE '%$query%'";
        $result = $conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $courses[] = $row;
            }
        } else if (APP_DEBUG) {
            // [VULNERABILITY: A05] SQL error message leaked in debug mode
            echo "<!-- SQL Error: " . $conn->error . " -->";
        }
    }

    if ($type === 'all' || $type === 'faculty') {
        // [VULNERABILITY: A03 - SQL Injection] Same pattern — unsanitized input in query
        $sql2 = "SELECT id, full_name, email, department, bio
                 FROM users
                 WHERE role IN ('teacher','admin')
                   AND (full_name LIKE '%$query%' OR department LIKE '%$query%')";
        $result2 = $conn->query($sql2);
        if ($result2) {
            while ($row = $result2->fetch_assoc()) {
                $faculty[] = $row;
            }
        }
    }

    // [VULNERABILITY: A01] Student search returns sensitive data to unauthenticated users
    if (isLoggedIn() && ($type === 'all' || $type === 'students')) {
        // [VULNERABILITY: A03 - SQL Injection] Third vulnerable query
        // UNION attack: ' UNION SELECT id,username,password,email,ssn,role,student_id,bio FROM users --
        $sql3 = "SELECT id, full_name, student_id, department, year, gpa
                 FROM users
                 WHERE role = 'student'
                   AND (full_name LIKE '%$query%' OR student_id LIKE '%$query%')";
        $result3 = $conn->query($sql3);
        if ($result3) {
            while ($row = $result3->fetch_assoc()) {
                $students[] = $row;
            }
        }
    }
}

$totalResults = count($courses) + count($faculty) + count($students);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Results | Code Academy University</title>
    <link rel="stylesheet" href="/css/main.css">
    <!-- [VULNERABILITY: A06] Outdated jQuery -->
    <script src="https://code.jquery.com/jquery-1.8.3.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/../src/views/partials/nav.php'; ?>

<div class="page-hero small">
    <div class="container">
        <h1>Search Results</h1>
        <!-- [VULNERABILITY: A03 - Reflected XSS] Query echoed without encoding -->
        <!-- Exploit: /search.php?q=<script>alert(1)</script> -->
        <?php if ($query): ?>
        <p>Showing results for: <strong><?php echo $query; // [VULNERABILITY: A03 - XSS] ?></strong></p>
        <?php endif; ?>
    </div>
</div>

<div class="container search-page">
    <form action="/search.php" method="GET" class="search-bar">
        <input type="text" name="q" class="search-input"
               value="<?php echo $query; // [VULNERABILITY: A03 - XSS] ?>"
               placeholder="Search courses, faculty, students...">
        <select name="type" class="form-select">
            <option value="all" <?= $type === 'all' ? 'selected' : '' ?>>All</option>
            <option value="courses" <?= $type === 'courses' ? 'selected' : '' ?>>Courses</option>
            <option value="faculty" <?= $type === 'faculty' ? 'selected' : '' ?>>Faculty</option>
            <option value="students" <?= $type === 'students' ? 'selected' : '' ?>>Students</option>
        </select>
        <button type="submit" class="btn btn-primary">Search</button>
    </form>

    <?php if ($query && $totalResults === 0): ?>
    <div class="no-results">
        <div class="no-results-icon">🔍</div>
        <h2>No results found</h2>
        <!-- [VULNERABILITY: A03 - XSS] Query reflected again here -->
        <p>We couldn't find anything matching "<?php echo $query; ?>"</p>
    </div>
    <?php endif; ?>

    <!-- Course Results -->
    <?php if (!empty($courses)): ?>
    <section class="search-section">
        <h2>Courses (<?php echo count($courses); ?>)</h2>
        <div class="search-results">
        <?php foreach ($courses as $c): ?>
            <div class="search-result-card">
                <div class="result-code"><?php echo htmlspecialchars($c['code']); ?></div>
                <div class="result-body">
                    <h3><?php echo htmlspecialchars($c['name']); ?></h3>
                    <p><?php echo htmlspecialchars(substr($c['description'], 0, 150)); ?>...</p>
                    <div class="result-meta">
                        <span>📚 <?php echo $c['credits']; ?> Credits</span>
                        <span>📅 <?php echo htmlspecialchars($c['semester']); ?></span>
                    </div>
                </div>
                <a href="/courses.php?id=<?php echo $c['id']; ?>" class="btn btn-sm">View</a>
            </div>
        <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- Faculty Results -->
    <?php if (!empty($faculty)): ?>
    <section class="search-section">
        <h2>Faculty (<?php echo count($faculty); ?>)</h2>
        <div class="search-results">
        <?php foreach ($faculty as $f): ?>
            <div class="search-result-card">
                <div class="result-avatar"><?php echo strtoupper(substr($f['full_name'], 0, 2)); ?></div>
                <div class="result-body">
                    <h3><?php echo htmlspecialchars($f['full_name']); ?></h3>
                    <p><?php echo htmlspecialchars($f['department']); ?></p>
                    <p><?php echo htmlspecialchars($f['email']); ?></p>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- Student Results -->
    <?php if (!empty($students)): ?>
    <section class="search-section">
        <h2>Students (<?php echo count($students); ?>)</h2>
        <div class="search-results">
        <?php foreach ($students as $s): ?>
            <div class="search-result-card">
                <div class="result-avatar"><?php echo strtoupper(substr($s['full_name'], 0, 2)); ?></div>
                <div class="result-body">
                    <h3><?php echo htmlspecialchars($s['full_name']); ?></h3>
                    <p><?php echo htmlspecialchars($s['department']); ?> · Year <?php echo $s['year']; ?></p>
                    <span class="result-gpa">GPA: <?php echo $s['gpa']; ?></span>
                </div>
                <?php if (isLoggedIn()): ?>
                <a href="/portal/profile.php?id=<?php echo $s['id']; ?>" class="btn btn-sm">View Profile</a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../src/views/partials/footer.php'; ?>
</body>
</html>
