<?php
// public/portal/dashboard.php
require_once __DIR__ . '/../../src/config/auth.php';
requireLogin();

$user = getCurrentUser();
$db   = getDB();

// Get enrolled courses
$stmt = $db->prepare("
    SELECT c.*, e.grade, e.grade_points
    FROM enrollments e
    JOIN courses c ON e.course_id = c.id
    WHERE e.student_id = ?
");
$stmt->execute([$user['id']]);
$enrollments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent messages
$stmt2 = $db->prepare("
    SELECT m.*, u.full_name AS sender_name
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.recipient_id = ? OR m.is_public = 1
    ORDER BY m.created_at DESC LIMIT 5
");
$stmt2->execute([$user['id']]);
$messages = $stmt2->fetchAll(PDO::FETCH_ASSOC);

// GPA calculation
$totalPoints = array_sum(array_column($enrollments, 'grade_points'));
$gpa = count($enrollments) > 0 ? round($totalPoints / count($enrollments), 2) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard | CAU Student Portal</title>
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="/css/portal.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="portal-page">
<?php include __DIR__ . '/../../src/views/partials/portal_nav.php'; ?>

<div class="portal-layout">
    <?php include __DIR__ . '/../../src/views/partials/portal_sidebar.php'; ?>

    <main class="portal-main">
        <div class="portal-header">
            <div>
                <h1>Welcome back, <?php echo htmlspecialchars($user['full_name']); ?> 👋</h1>
                <p>Fall 2024 Semester · <?php echo htmlspecialchars($user['department']); ?></p>
            </div>
            <div class="portal-header-meta">
                <span class="badge badge-<?php echo $user['role']; ?>"><?php echo ucfirst($user['role']); ?></span>
                <span class="student-id">ID: <?php echo htmlspecialchars($user['student_id']); ?></span>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-icon">📚</div>
                <div class="stat-info">
                    <span class="stat-num"><?php echo count($enrollments); ?></span>
                    <span class="stat-label">Enrolled Courses</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⭐</div>
                <div class="stat-info">
                    <span class="stat-num"><?php echo $gpa; ?></span>
                    <span class="stat-label">Current GPA</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">💬</div>
                <div class="stat-info">
                    <span class="stat-num"><?php echo count($messages); ?></span>
                    <span class="stat-label">Messages</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🎯</div>
                <div class="stat-info">
                    <span class="stat-num">Year <?php echo $user['year'] ?? 'N/A'; ?></span>
                    <span class="stat-label">Academic Standing</span>
                </div>
            </div>
        </div>

        <!-- My Courses -->
        <section class="portal-section">
            <div class="section-head">
                <h2>My Courses</h2>
                <a href="/portal/courses.php" class="btn btn-sm">View All</a>
            </div>
            <div class="courses-table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Course Name</th>
                            <th>Credits</th>
                            <th>Schedule</th>
                            <th>Grade</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($enrollments as $e): ?>
                        <tr>
                            <td><code><?php echo htmlspecialchars($e['code']); ?></code></td>
                            <td><?php echo htmlspecialchars($e['name']); ?></td>
                            <td><?php echo $e['credits']; ?></td>
                            <td><?php echo htmlspecialchars($e['schedule']); ?></td>
                            <td>
                                <span class="grade-badge grade-<?php echo strtolower(str_replace(['+','-'], '', $e['grade'] ?? 'ng')); ?>">
                                    <?php echo $e['grade'] ?? 'In Progress'; ?>
                                </span>
                            </td>
                            <td><a href="/portal/course-detail.php?id=<?php echo $e['id']; ?>" class="table-link">Details</a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <!-- Recent Messages -->
        <section class="portal-section">
            <div class="section-head">
                <h2>Recent Messages</h2>
                <a href="/portal/messages.php" class="btn btn-sm">View All</a>
            </div>
            <div class="messages-list">
            <?php foreach ($messages as $msg): ?>
                <div class="message-item">
                    <div class="msg-avatar"><?php echo strtoupper(substr($msg['sender_name'], 0, 1)); ?></div>
                    <div class="msg-content">
                        <!-- [VULNERABILITY: A03 - Stored XSS] Subject rendered without escaping -->
                        <!-- Payload sent via /portal/messages.php POST -->
                        <div class="msg-subject"><?php echo $msg['subject']; // [VULNERABILITY: A03 - XSS] ?></div>
                        <div class="msg-meta">
                            <span><?php echo htmlspecialchars($msg['sender_name']); ?></span>
                            <span><?php echo date('M d, g:i a', strtotime($msg['created_at'])); ?></span>
                        </div>
                    </div>
                    <?php if ($msg['is_public']): ?>
                    <span class="msg-tag">Public</span>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
            </div>
        </section>
    </main>
</div>
<script src="/js/portal.js"></script>
</body>
</html>
