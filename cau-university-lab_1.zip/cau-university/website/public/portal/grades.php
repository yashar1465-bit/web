<?php
// public/portal/grades.php
// [VULNERABILITY: A01 - Broken Access Control / IDOR]
// student_id param can be changed to view ANY student's grades

require_once __DIR__ . '/../../src/config/auth.php';
requireLogin();

$db = getDB();

// [VULNERABILITY: A01 - IDOR]
// No authorization check — any logged-in user can view any student's grades
// Exploit: change ?student_id=1 to ?student_id=2, ?student_id=3, etc.
$targetStudentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : $_SESSION['user_id'];

// Fetch the target student
$stmt = $db->prepare("SELECT id, full_name, student_id, department, year, gpa FROM users WHERE id = ?");
$stmt->execute([$targetStudentId]);
$targetStudent = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$targetStudent) {
    die('<h2>Student not found.</h2>');
}

// Fetch grades — no role check, anyone can see anyone's grades
$gradeStmt = $db->prepare("
    SELECT e.*, c.code, c.name AS course_name, c.credits, c.semester
    FROM enrollments e
    JOIN courses c ON e.course_id = c.id
    WHERE e.student_id = ?
    ORDER BY c.semester DESC, c.code ASC
");
$gradeStmt->execute([$targetStudentId]);
$grades = $gradeStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate GPA
$totalPoints  = 0;
$totalCredits = 0;
foreach ($grades as $g) {
    if ($g['grade_points'] !== null) {
        $totalPoints  += $g['grade_points'] * $g['credits'];
        $totalCredits += $g['credits'];
    }
}
$calculatedGpa = $totalCredits > 0 ? round($totalPoints / $totalCredits, 2) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Grades | CAU Portal</title>
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="/css/portal.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="portal-page">
<?php include __DIR__ . '/../../src/views/partials/portal_nav.php'; ?>

<div class="portal-layout">
    <?php include __DIR__ . '/../../src/views/partials/portal_sidebar.php'; ?>

    <main class="portal-main">
        <div class="portal-header">
            <div>
                <h1>Academic Transcript</h1>
                <!-- [VULNERABILITY: A01] Viewing another student's transcript — no access control -->
                <?php if ($targetStudentId !== (int)$_SESSION['user_id']): ?>
                <div class="alert alert-warning" style="margin-top:8px;">
                    ⚠️ You are viewing grades for: <strong><?php echo htmlspecialchars($targetStudent['full_name']); ?></strong>
                    (Student ID: <?php echo htmlspecialchars($targetStudent['student_id']); ?>)
                </div>
                <?php endif; ?>
            </div>
            <a href="/portal/grades.php?student_id=<?php echo $targetStudentId; ?>&format=print" class="btn btn-sm">🖨 Print</a>
        </div>

        <!-- GPA Summary -->
        <div class="gpa-summary">
            <div class="gpa-card main-gpa">
                <div class="gpa-num"><?php echo $calculatedGpa; ?></div>
                <div class="gpa-label">Cumulative GPA</div>
            </div>
            <div class="gpa-card">
                <div class="gpa-num"><?php echo count($grades); ?></div>
                <div class="gpa-label">Total Courses</div>
            </div>
            <div class="gpa-card">
                <div class="gpa-num"><?php echo $totalCredits; ?></div>
                <div class="gpa-label">Credits Earned</div>
            </div>
            <div class="gpa-card">
                <div class="gpa-num"><?php echo $targetStudent['year'] ?? 'N/A'; ?></div>
                <div class="gpa-label">Academic Year</div>
            </div>
        </div>

        <!-- Grades Table -->
        <section class="portal-section">
            <h2>Course Grades — <?php echo htmlspecialchars($targetStudent['full_name']); ?></h2>
            <div class="courses-table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Semester</th>
                            <th>Code</th>
                            <th>Course Name</th>
                            <th>Credits</th>
                            <th>Grade</th>
                            <th>Grade Points</th>
                            <th>Quality Points</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($grades as $g): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($g['semester']); ?></td>
                        <td><code><?php echo htmlspecialchars($g['code']); ?></code></td>
                        <td><?php echo htmlspecialchars($g['course_name']); ?></td>
                        <td><?php echo $g['credits']; ?></td>
                        <td>
                            <span class="grade-badge grade-<?php echo strtolower(str_replace(['+','-'], '', $g['grade'] ?? 'ip')); ?>">
                                <?php echo $g['grade'] ?? 'In Progress'; ?>
                            </span>
                        </td>
                        <td><?php echo $g['grade_points'] ?? '—'; ?></td>
                        <td><?php echo $g['grade_points'] !== null ? ($g['grade_points'] * $g['credits']) : '—'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr class="totals-row">
                            <td colspan="3"><strong>Totals / GPA</strong></td>
                            <td><strong><?php echo $totalCredits; ?></strong></td>
                            <td>—</td>
                            <td>—</td>
                            <td><strong><?php echo $calculatedGpa; ?></strong></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </section>

        <!-- Student selector (makes IDOR easy to demo) -->
        <section class="portal-section">
            <h2>View Another Student's Grades</h2>
            <!-- [VULNERABILITY: A01] Explicit form to exploit IDOR for educational demonstration -->
            <p class="hint-text">Enter a student ID number to view their transcript:</p>
            <form method="GET" class="inline-form">
                <input type="number" name="student_id" class="form-input"
                       value="<?php echo $targetStudentId; ?>" min="1" max="20" style="width:120px">
                <button type="submit" class="btn btn-primary">View Grades</button>
            </form>
        </section>
    </main>
</div>
<script src="/js/portal.js"></script>
</body>
</html>
