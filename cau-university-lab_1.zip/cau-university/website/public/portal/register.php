<?php
// public/portal/register.php
require_once __DIR__ . '/../../src/config/auth.php';
requireLogin();

$db      = getDB();
$success = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $courseId = (int)($_POST['course_id'] ?? 0);

    // Check if already enrolled
    $check = $db->prepare("SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?");
    $check->execute([$_SESSION['user_id'], $courseId]);

    if ($check->fetch()) {
        $error = 'You are already enrolled in this course.';
    } else {
        $enroll = $db->prepare("INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)");
        $enroll->execute([$_SESSION['user_id'], $courseId]);
        $db->prepare("UPDATE courses SET enrolled = enrolled + 1 WHERE id = ?")->execute([$courseId]);
        $success = 'Successfully registered for the course!';
    }
}

// Handle URL param for quick enroll
$preselect = (int)($_GET['course'] ?? 0);

// Get available courses not yet enrolled in
$stmt = $db->prepare("
    SELECT c.*, u.full_name AS teacher_name,
           (SELECT COUNT(*) FROM enrollments e WHERE e.student_id = ? AND e.course_id = c.id) AS already_enrolled
    FROM courses c
    LEFT JOIN users u ON c.teacher_id = u.id
    ORDER BY c.code
");
$stmt->execute([$_SESSION['user_id']]);
$allCourses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Course Registration | CAU Portal</title>
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="/css/portal.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="portal-page">
<?php include __DIR__ . '/../../src/views/partials/portal_nav.php'; ?>

<div class="portal-layout">
    <?php include __DIR__ . '/../../src/views/partials/portal_sidebar.php'; ?>

    <main class="portal-main">
        <div class="portal-header">
            <h1>Course Registration</h1>
            <p>Fall 2024 · Registration Period: Aug 1 – Aug 31</p>
        </div>

        <?php if ($success): ?>
        <div class="alert alert-success">✅ <?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
        <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="register-grid">
        <?php foreach ($allCourses as $c): ?>
            <div class="register-card <?php echo $c['already_enrolled'] ? 'enrolled' : ''; ?> <?php echo $c['id'] == $preselect ? 'highlighted' : ''; ?>">
                <div class="register-card-header">
                    <span class="catalog-code"><?php echo htmlspecialchars($c['code']); ?></span>
                    <span class="catalog-credits"><?php echo $c['credits']; ?> credits</span>
                </div>
                <h3><?php echo htmlspecialchars($c['name']); ?></h3>
                <p><?php echo htmlspecialchars(substr($c['description'], 0, 100)); ?>...</p>
                <div class="catalog-meta">
                    <span>👤 <?php echo htmlspecialchars($c['teacher_name'] ?? 'TBA'); ?></span>
                    <span>🕐 <?php echo htmlspecialchars($c['schedule']); ?></span>
                    <span>👥 <?php echo $c['enrolled']; ?>/<?php echo $c['capacity']; ?></span>
                </div>
                <div class="register-action">
                    <?php if ($c['already_enrolled']): ?>
                        <span class="badge badge-enrolled">✅ Enrolled</span>
                    <?php elseif ($c['enrolled'] >= $c['capacity']): ?>
                        <span class="badge badge-full">❌ Full</span>
                    <?php else: ?>
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="course_id" value="<?php echo $c['id']; ?>">
                            <button type="submit" class="btn btn-primary btn-sm">Register</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    </main>
</div>
<script src="/js/portal.js"></script>
</body>
</html>
