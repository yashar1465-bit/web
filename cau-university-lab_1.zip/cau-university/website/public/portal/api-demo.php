<?php
// public/portal/api-demo.php
// Demonstrates the internal API — shows how the website talks to the Flask service
// [VULNERABILITY: A04 - Insecure Design] API has no auth, exposed to host network

require_once __DIR__ . '/../../src/config/auth.php';
requireLogin();

$apiUrl = API_URL;

// Proxy-style call to internal API — demonstrates the integration
$apiResponse = null;
$apiEndpoint = $_GET['endpoint'] ?? 'students';
$apiParam    = $_GET['param']    ?? '';

// [VULNERABILITY: A04] Direct passthrough to internal unauthenticated API
$url = $apiUrl . '/' . urlencode($apiEndpoint);
if ($apiParam) {
    $url .= '/' . urlencode($apiParam);
}

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$raw = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$apiResponse = $raw;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>API Explorer | CAU Portal</title>
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="/css/portal.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="portal-page">
<?php include __DIR__ . '/../../src/views/partials/portal_nav.php'; ?>

<div class="portal-layout">
    <?php include __DIR__ . '/../../src/views/partials/portal_sidebar.php'; ?>

    <main class="portal-main">
        <div class="portal-header">
            <h1>🔌 Internal API Explorer</h1>
            <p>Explore the university's internal student data API (Development Tool)</p>
        </div>

        <div class="alert alert-warning">
            ⚠️ <strong>Developer Note:</strong> This API explorer connects to the internal microservice at
            <code><?php echo htmlspecialchars($apiUrl); ?></code>.
            <!-- [VULNERABILITY: A04 / A05] Internal service URL revealed -->
        </div>

        <section class="portal-section">
            <h2>Available Endpoints</h2>
            <div class="api-endpoints">
                <div class="api-endpoint">
                    <span class="method get">GET</span>
                    <code>/students</code>
                    <span class="desc">List all students with sensitive data — no auth required</span>
                    <a href="?endpoint=students" class="btn btn-sm">Try</a>
                </div>
                <div class="api-endpoint">
                    <span class="method get">GET</span>
                    <code>/students/{id}</code>
                    <span class="desc">Full student record including SSN — no auth required</span>
                    <a href="?endpoint=students&param=1" class="btn btn-sm">Try</a>
                </div>
                <div class="api-endpoint">
                    <span class="method get">GET</span>
                    <code>/grades/{student_id}</code>
                    <span class="desc">All grades for any student — no auth required</span>
                    <a href="?endpoint=grades&param=1" class="btn btn-sm">Try</a>
                </div>
                <div class="api-endpoint">
                    <span class="method get">GET</span>
                    <code>/health</code>
                    <span class="desc">Service health — reveals DB connection info</span>
                    <a href="?endpoint=health" class="btn btn-sm">Try</a>
                </div>
                <div class="api-endpoint">
                    <span class="method get">GET</span>
                    <code>/debug</code>
                    <span class="desc">Debug endpoint — dumps environment variables</span>
                    <a href="?endpoint=debug" class="btn btn-sm">Try</a>
                </div>
                <div class="api-endpoint">
                    <span class="method get">GET</span>
                    <code>/users</code>
                    <span class="desc">All users including hashed passwords — no auth required</span>
                    <a href="?endpoint=users" class="btn btn-sm">Try</a>
                </div>
            </div>
        </section>

        <section class="portal-section">
            <h2>API Response</h2>
            <p>Endpoint called: <code><?php echo htmlspecialchars($url); ?></code> — HTTP <?php echo $httpCode; ?></p>
            <pre class="api-response"><?php
                $decoded = json_decode($apiResponse, true);
                echo htmlspecialchars(json_encode($decoded, JSON_PRETTY_PRINT));
            ?></pre>
        </section>

        <section class="portal-section">
            <h2>Direct API Access</h2>
            <p>The API is also directly accessible at port 5000 from outside Docker (no authentication):</p>
            <div class="code-block">
                <code>curl http://localhost:5000/students</code><br>
                <code>curl http://localhost:5000/students/1</code><br>
                <code>curl http://localhost:5000/users</code><br>
                <code>curl http://localhost:5000/debug</code>
            </div>
            <!-- [VULNERABILITY: A04 / A05] Instructions for accessing unauthenticated internal API -->
        </section>
    </main>
</div>
<script src="/js/portal.js"></script>
</body>
</html>
