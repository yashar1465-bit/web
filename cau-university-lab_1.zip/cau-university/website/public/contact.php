<?php
// public/contact.php
require_once __DIR__ . '/../src/config/auth.php';

$success = false;
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name && $email && $subject && $message) {
        $db   = getDB();
        $stmt = $db->prepare("INSERT INTO contact_submissions (name, email, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $email, $subject, $message]);
        $success = true;
    } else {
        $error = 'Please fill in all fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us | Code Academy University</title>
    <link rel="stylesheet" href="/css/main.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/../src/views/partials/nav.php'; ?>

<div class="page-hero small">
    <div class="container">
        <h1>Contact Us</h1>
        <p>Have questions about admissions, academics, or campus life? We're here to help.</p>
    </div>
</div>

<div class="container contact-page">
    <div class="contact-grid">
        <div class="contact-info">
            <h2>Get in Touch</h2>
            <div class="contact-items">
                <div class="contact-item">
                    <div class="contact-icon">📍</div>
                    <div>
                        <h4>Campus Address</h4>
                        <p>100 University Drive<br>Campus Town, CT 06001</p>
                    </div>
                </div>
                <div class="contact-item">
                    <div class="contact-icon">📞</div>
                    <div>
                        <h4>Phone</h4>
                        <p>Main: (800) 555-1234<br>Admissions: (800) 555-5678</p>
                    </div>
                </div>
                <div class="contact-item">
                    <div class="contact-icon">✉️</div>
                    <div>
                        <h4>Email</h4>
                        <p>info@cau.edu<br>admissions@cau.edu</p>
                    </div>
                </div>
                <div class="contact-item">
                    <div class="contact-icon">🕐</div>
                    <div>
                        <h4>Office Hours</h4>
                        <p>Mon–Fri: 8:00 AM – 5:00 PM<br>Sat: 9:00 AM – 12:00 PM</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="contact-form-wrap">
            <?php if ($success): ?>
            <div class="alert alert-success">
                <h3>✅ Message Sent!</h3>
                <p>Thank you for contacting us. We'll respond within 1–2 business days.</p>
            </div>
            <?php else: ?>
            <?php if ($error): ?>
            <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form method="POST" class="contact-form">
                <div class="form-row">
                    <div class="form-group">
                        <label>Full Name *</label>
                        <input type="text" name="name" class="form-input" required
                               value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Email Address *</label>
                        <input type="email" name="email" class="form-input" required
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label>Subject *</label>
                    <select name="subject" class="form-select" required>
                        <option value="">Select a topic...</option>
                        <option>Admissions Inquiry</option>
                        <option>Program Information</option>
                        <option>Financial Aid</option>
                        <option>Campus Visit</option>
                        <option>Technical Support</option>
                        <option>Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Message *</label>
                    <textarea name="message" rows="6" class="form-textarea" required
                              placeholder="Tell us how we can help..."><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-full">Send Message</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../src/views/partials/footer.php'; ?>
</body>
</html>
