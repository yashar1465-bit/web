// public/js/main.js
// Code Academy University — Main JS
// [VULNERABILITY: A06] Running alongside jQuery 1.8.3 (severely outdated)

document.addEventListener('DOMContentLoaded', function () {

    // ── Sticky header scroll effect ───────────────────────────
    const header = document.getElementById('site-header');
    if (header) {
        window.addEventListener('scroll', function () {
            if (window.scrollY > 40) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }

    // ── Mobile menu toggle ────────────────────────────────────
    const mobileToggle = document.getElementById('mobileMenuToggle');
    const navLinks     = document.querySelector('.nav-links');
    if (mobileToggle && navLinks) {
        mobileToggle.addEventListener('click', function () {
            navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
        });
    }

    // ── Animate stats on scroll ───────────────────────────────
    const statsObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
                statsObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });

    document.querySelectorAll('.stat, .program-card, .news-card').forEach(function (el) {
        statsObserver.observe(el);
    });

    // ── Flash message auto-dismiss ────────────────────────────
    const flash = document.querySelector('.flash-message');
    if (flash) {
        setTimeout(function () {
            flash.style.transition = 'opacity 0.5s ease';
            flash.style.opacity    = '0';
            setTimeout(function () { flash.remove(); }, 500);
        }, 5000);
    }

    // ── Form validation UX ────────────────────────────────────
    document.querySelectorAll('form').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            const btn = form.querySelector('button[type="submit"]');
            if (btn && !btn.disabled) {
                btn.textContent = 'Processing...';
                btn.disabled = true;
                // Re-enable after 3s to avoid permanent lockout on validation errors
                setTimeout(function () {
                    btn.disabled = false;
                    btn.textContent = btn.dataset.originalText || 'Submit';
                }, 3000);
            }
        });
    });
});
