// public/js/portal.js
// Code Academy University — Portal JS

document.addEventListener('DOMContentLoaded', function () {

    // ── Tab switching ─────────────────────────────────────────
    document.querySelectorAll('.tab-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const target = this.dataset.tab;

            // Deactivate all tabs
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

            // Activate clicked tab
            this.classList.add('active');
            const content = document.getElementById('tab-' + target);
            if (content) content.classList.add('active');
        });
    });

    // ── Student ID param changer for IDOR demo ────────────────
    // [VULNERABILITY: A01] Helper that makes IDOR easier to exploit in the lab
    const idInput = document.querySelector('input[name="student_id"]');
    if (idInput) {
        idInput.addEventListener('keydown', function (e) {
            if (e.key === 'ArrowUp') {
                e.preventDefault();
                this.value = Math.max(1, parseInt(this.value || 1) + 1);
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.value = Math.max(1, parseInt(this.value || 2) - 1);
            }
        });
    }

    // ── Auto-highlight active sidebar item ────────────────────
    const currentPath = window.location.pathname;
    document.querySelectorAll('.sidebar-nav a').forEach(function (link) {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });

    // ── Confirm before course drop ────────────────────────────
    document.querySelectorAll('.drop-course-btn').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            if (!confirm('Are you sure you want to drop this course?')) {
                e.preventDefault();
            }
        });
    });
});
