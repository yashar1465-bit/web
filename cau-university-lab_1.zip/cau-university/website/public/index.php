<?php
// public/index.php - Homepage
require_once __DIR__ . '/../src/config/auth.php';

// [VULNERABILITY: A03 - Reflected XSS]
// The 'msg' parameter is reflected directly into the page without sanitization
// Exploit: /?msg=<script>alert('XSS')</script>
$message = $_GET['msg'] ?? '';
$search  = $_GET['search'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Academy University | Shaping Tomorrow's Innovators</title>
    <link rel="stylesheet" href="/css/main.css">
    <!-- [VULNERABILITY: A06 - Vulnerable & Outdated Components] jQuery 1.8.3 (2012) -->
    <script src="https://code.jquery.com/jquery-1.8.3.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/../src/views/partials/nav.php'; ?>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-bg"></div>
    <div class="hero-content">
        <span class="hero-tagline">Est. 1965 · Excellence in Technology Education</span>
        <h1>Code Academy<br><span class="hero-accent">University</span></h1>
        <p class="hero-sub">Where innovation meets education. Preparing the next generation of technology leaders through rigorous academics and hands-on experience.</p>
        <div class="hero-actions">
            <a href="/admissions.php" class="btn btn-primary">Apply Now</a>
            <a href="/courses.php" class="btn btn-outline">Explore Programs</a>
        </div>
    </div>
    <div class="hero-stats">
        <div class="stat"><span class="stat-num">12,400+</span><span class="stat-label">Students Enrolled</span></div>
        <div class="stat"><span class="stat-num">240+</span><span class="stat-label">Expert Faculty</span></div>
        <div class="stat"><span class="stat-num">95%</span><span class="stat-label">Employment Rate</span></div>
        <div class="stat"><span class="stat-num">58</span><span class="stat-label">Years of Excellence</span></div>
    </div>
</section>

<?php if ($message): ?>
<!-- [VULNERABILITY: A03 - Reflected XSS] Message echoed without escaping -->
<!-- Payload: /?msg=<img src=x onerror=alert(document.cookie)> -->
<div class="flash-message">
    <div class="container">
        <?php echo $message; // [VULNERABILITY: A03 - XSS] NO htmlspecialchars() ?>
    </div>
</div>
<?php endif; ?>

<!-- Programs Section -->
<section class="section programs-section">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">Academic Excellence</span>
            <h2>Our Distinguished Programs</h2>
            <p>Choose from our nationally ranked programs designed to prepare you for the careers of tomorrow.</p>
        </div>
        <div class="programs-grid">
            <div class="program-card">
                <div class="program-icon">💻</div>
                <h3>Computer Science</h3>
                <p>From algorithms to AI, build the foundations of modern computing with world-class faculty.</p>
                <div class="program-meta"><span>120 Credits</span><span>4 Years</span></div>
                <a href="/courses.php?dept=CS" class="program-link">Explore →</a>
            </div>
            <div class="program-card featured">
                <div class="program-badge">Most Popular</div>
                <div class="program-icon">🔒</div>
                <h3>Cybersecurity</h3>
                <p>Master the art of digital defense, ethical hacking, and security architecture in our state-of-the-art labs.</p>
                <div class="program-meta"><span>126 Credits</span><span>4 Years</span></div>
                <a href="/courses.php?dept=SEC" class="program-link">Explore →</a>
            </div>
            <div class="program-card">
                <div class="program-icon">📊</div>
                <h3>Data Science</h3>
                <p>Harness the power of big data, machine learning, and predictive analytics to drive decisions.</p>
                <div class="program-meta"><span>118 Credits</span><span>4 Years</span></div>
                <a href="/courses.php?dept=DS" class="program-link">Explore →</a>
            </div>
            <div class="program-card">
                <div class="program-icon">⚙️</div>
                <h3>Software Engineering</h3>
                <p>Design, build, and deploy enterprise-grade software using industry-standard practices and methodologies.</p>
                <div class="program-meta"><span>122 Credits</span><span>4 Years</span></div>
                <a href="/courses.php?dept=SE" class="program-link">Explore →</a>
            </div>
        </div>
    </div>
</section>

<!-- Search Section -->
<section class="section search-section">
    <div class="container">
        <div class="search-card">
            <h2>Find Courses & Faculty</h2>
            <p>Search our catalog of over 300 courses and 240 expert faculty members.</p>
            <form action="/search.php" method="GET" class="search-form">
                <input type="text" name="q" class="search-input"
                       placeholder="e.g. 'Machine Learning', 'Prof. Chen', 'CS301'..."
                       value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="btn btn-primary">Search</button>
            </form>
        </div>
    </div>
</section>

<!-- News / Announcements -->
<section class="section news-section">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">Campus News</span>
            <h2>Latest Announcements</h2>
        </div>
        <div class="news-grid">
            <?php
            try {
                $db = getDB();
                $stmt = $db->query("SELECT a.*, u.full_name FROM announcements a LEFT JOIN users u ON a.author_id = u.id ORDER BY a.created_at DESC LIMIT 3");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
            ?>
            <article class="news-card">
                <div class="news-date"><?php echo date('M d, Y', strtotime($row['created_at'])); ?></div>
                <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                <p><?php echo htmlspecialchars(substr($row['content'], 0, 150)) . '...'; ?></p>
                <span class="news-author">Posted by <?php echo htmlspecialchars($row['full_name'] ?? 'Administration'); ?></span>
            </article>
            <?php endwhile; } catch(Exception $e) { echo '<p>Unable to load announcements.</p>'; } ?>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="section cta-section">
    <div class="container">
        <div class="cta-inner">
            <h2>Ready to Begin Your Journey?</h2>
            <p>Join 12,400+ students building the future at Code Academy University. Applications for Fall 2025 are now open.</p>
            <div class="cta-actions">
                <a href="/admissions.php" class="btn btn-primary btn-lg">Apply for Fall 2025</a>
                <a href="/contact.php" class="btn btn-outline btn-lg">Request Information</a>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../src/views/partials/footer.php'; ?>
<script src="/js/main.js"></script>
</body>
</html>
