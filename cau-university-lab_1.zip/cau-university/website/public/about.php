<?php require_once __DIR__ . '/../src/config/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us | Code Academy University</title>
    <link rel="stylesheet" href="/css/main.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/../src/views/partials/nav.php'; ?>

<div class="page-hero">
    <div class="container">
        <span class="hero-tag">Est. 1965</span>
        <h1>About Code Academy University</h1>
        <p>Six decades of excellence in technology education, research, and innovation.</p>
    </div>
</div>

<section class="section">
    <div class="container">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center;">
            <div>
                <span class="section-tag">Our Mission</span>
                <h2 style="margin:12px 0 20px;">Shaping Tomorrow's Technology Leaders</h2>
                <p style="color:var(--gray-600);line-height:1.8;margin-bottom:16px;">Code Academy University was founded in 1965 with a singular vision: to create a world-class institution dedicated to the intersection of computer science, engineering, and innovation. Today, we are proud to be home to over 12,400 students from 87 countries and 240 expert faculty members.</p>
                <p style="color:var(--gray-600);line-height:1.8;margin-bottom:28px;">Our graduates lead engineering teams at Google, Apple, Amazon, and hundreds of innovative startups. We combine rigorous theoretical foundations with intensive hands-on practice in our state-of-the-art laboratories.</p>
                <a href="/admissions.php" class="btn btn-primary">Begin Your Journey</a>
            </div>
            <div style="background:var(--navy);border-radius:var(--radius-lg);padding:40px;color:white;">
                <h3 style="color:var(--gold);margin-bottom:24px;">By The Numbers</h3>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
                    <?php foreach ([['12,400+','Students Enrolled'],['240+','Expert Faculty'],['95%','Employment Rate'],['87','Countries Represented'],['$2.4M','Research Funding'],['1965','Year Founded']] as [$n,$l]): ?>
                    <div style="text-align:center;padding:16px;background:rgba(255,255,255,.05);border-radius:8px;">
                        <div style="font-family:var(--font-display);font-size:1.6rem;color:var(--gold);font-weight:700;"><?= $n ?></div>
                        <div style="font-size:.78rem;color:rgba(255,255,255,.6);text-transform:uppercase;letter-spacing:.05em;margin-top:4px;"><?= $l ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section" style="background:var(--off-white);">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">Leadership</span>
            <h2>Meet Our Faculty</h2>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:24px;">
        <?php
        $db = getDB();
        $faculty = $db->query("SELECT * FROM users WHERE role = 'teacher'")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($faculty as $f):
        ?>
        <div style="background:var(--white);border:1px solid var(--gray-200);border-radius:var(--radius-lg);padding:28px;text-align:center;">
            <div style="width:72px;height:72px;border-radius:50%;background:var(--navy);color:var(--gold);display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:700;margin:0 auto 16px;">
                <?= strtoupper(substr($f['full_name'],0,2)) ?>
            </div>
            <h3 style="margin-bottom:4px;font-size:1.05rem;"><?= htmlspecialchars($f['full_name']) ?></h3>
            <p style="color:var(--gold);font-size:.82rem;font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px;"><?= htmlspecialchars($f['department']) ?></p>
            <p style="color:var(--gray-600);font-size:.87rem;"><?= htmlspecialchars(substr($f['bio'],0,100)) ?>...</p>
        </div>
        <?php endforeach; ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../src/views/partials/footer.php'; ?>
</body>
</html>
