<?php
// public/courses.php
require_once __DIR__ . '/../src/config/auth.php';
$db   = getDB();
$dept = $_GET['dept'] ?? '';

$sql  = "SELECT c.*, u.full_name AS teacher_name FROM courses c LEFT JOIN users u ON c.teacher_id = u.id";
$params = [];
if ($dept) {
    $sql .= " WHERE c.code LIKE ?";
    $params[] = $dept . '%';
}
$sql .= " ORDER BY c.code";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Course Catalog | Code Academy University</title>
    <link rel="stylesheet" href="/css/main.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/../src/views/partials/nav.php'; ?>

<div class="page-hero small">
    <div class="container">
        <span class="hero-tag">Academics</span>
        <h1>Course Catalog</h1>
        <p>Explore our comprehensive offerings across all departments for Fall 2024.</p>
    </div>
</div>

<div class="container">
    <div class="filter-bar">
        <a href="/courses.php" class="filter-btn <?= !$dept ? 'active' : '' ?>">All Departments</a>
        <a href="/courses.php?dept=CS"   class="filter-btn <?= $dept === 'CS'   ? 'active' : '' ?>">Computer Science</a>
        <a href="/courses.php?dept=CS4"  class="filter-btn <?= $dept === 'CS4'  ? 'active' : '' ?>">Cybersecurity</a>
        <a href="/courses.php?dept=DS"   class="filter-btn <?= $dept === 'DS'   ? 'active' : '' ?>">Data Science</a>
        <a href="/courses.php?dept=SE"   class="filter-btn <?= $dept === 'SE'   ? 'active' : '' ?>">Software Eng.</a>
        <a href="/courses.php?dept=MATH" class="filter-btn <?= $dept === 'MATH' ? 'active' : '' ?>">Mathematics</a>
    </div>

    <div class="courses-catalog">
    <?php foreach ($courses as $c): ?>
        <div class="catalog-card">
            <div class="catalog-header">
                <span class="catalog-code"><?php echo htmlspecialchars($c['code']); ?></span>
                <span class="catalog-credits"><?php echo $c['credits']; ?> cr.</span>
            </div>
            <h3><?php echo htmlspecialchars($c['name']); ?></h3>
            <p><?php echo htmlspecialchars($c['description']); ?></p>
            <div class="catalog-meta">
                <span>👤 <?php echo htmlspecialchars($c['teacher_name'] ?? 'TBA'); ?></span>
                <span>🕐 <?php echo htmlspecialchars($c['schedule']); ?></span>
                <span>🚪 <?php echo htmlspecialchars($c['room']); ?></span>
                <span>👥 <?php echo $c['enrolled']; ?>/<?php echo $c['capacity']; ?> enrolled</span>
            </div>
            <div class="catalog-footer">
                <span class="availability <?= $c['enrolled'] < $c['capacity'] ? 'open' : 'full'; ?>">
                    <?= $c['enrolled'] < $c['capacity'] ? '✅ Open' : '❌ Full'; ?>
                </span>
                <?php if (isLoggedIn()): ?>
                <a href="/portal/register.php?course=<?php echo $c['id']; ?>" class="btn btn-sm">Register</a>
                <?php else: ?>
                <a href="/auth/login.php" class="btn btn-sm btn-outline">Login to Register</a>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</div>

<?php include __DIR__ . '/../src/views/partials/footer.php'; ?>
</body>
</html>
