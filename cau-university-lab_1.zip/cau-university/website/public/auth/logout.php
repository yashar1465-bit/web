<?php
// public/auth/logout.php
require_once __DIR__ . '/../../src/config/auth.php';
logout();
