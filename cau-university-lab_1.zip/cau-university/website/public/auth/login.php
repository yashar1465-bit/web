<?php
// public/auth/login.php
require_once __DIR__ . '/../../src/config/auth.php';

if (isLoggedIn()) {
    header('Location: /portal/dashboard.php');
    exit;
}

$error = '';
$username_val = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $username_val = $username;

    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        // [VULNERABILITY: A03 - SQL Injection] loginUser() uses raw string concatenation
        // Classic bypass: username = admin' -- (comments out password check)
        //                 username = ' OR 1=1 LIMIT 1 --
        $user = loginUser($username, $password);
        if ($user) {
            header('Location: /portal/dashboard.php');
            exit;
        } else {
            // [VULNERABILITY: A07] Verbose error message confirms user existence
            $conn = getMysqli();
            $check = $conn->query("SELECT id FROM users WHERE username = '" . $conn->real_escape_string($username) . "'");
            if ($check && $check->num_rows > 0) {
                $error = 'Incorrect password. Please try again.'; // [VULNERABILITY: A07] User enumeration
            } else {
                $error = 'No account found with that username.';  // [VULNERABILITY: A07] User enumeration
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login | Code Academy University</title>
    <link rel="stylesheet" href="/css/main.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Source+Sans+Pro:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-sidebar">
            <div class="auth-sidebar-content">
                <a href="/" class="auth-logo">
                    <span>🎓</span>
                    <div>
                        <strong>Code Academy</strong>
                        <small>University</small>
                    </div>
                </a>
                <h1>Welcome Back</h1>
                <p>Sign in to access your student portal, view grades, register for classes, and connect with peers.</p>
                <div class="auth-features">
                    <div class="auth-feature"><span>📚</span> Course Registration</div>
                    <div class="auth-feature"><span>📊</span> Grades & Transcripts</div>
                    <div class="auth-feature"><span>💬</span> Campus Messaging</div>
                    <div class="auth-feature"><span>👤</span> Profile Management</div>
                </div>
            </div>
        </div>

        <div class="auth-form-panel">
            <div class="auth-form-wrapper">
                <h2>Sign In</h2>
                <p class="auth-subtitle">Enter your student credentials to continue</p>

                <?php if ($error): ?>
                <!-- [VULNERABILITY: A07] Error details help enumerate valid usernames -->
                <div class="alert alert-error">
                    <span>⚠️</span> <?php echo htmlspecialchars($error); ?>
                </div>
                <?php endif; ?>

                <!-- [VULNERABILITY: A03 - SQL Injection via loginUser() function] -->
                <!-- Try: username = admin'-- | password = anything -->
                <form method="POST" class="login-form" autocomplete="off">
                    <div class="form-group">
                        <label for="username">Username or Student ID</label>
                        <input type="text" id="username" name="username"
                               value="<?php echo htmlspecialchars($username_val); ?>"
                               placeholder="e.g. jsmith or STU001"
                               required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="password-field">
                            <input type="password" id="password" name="password"
                                   placeholder="Enter your password" required>
                            <button type="button" class="toggle-pwd" onclick="togglePassword()">👁</button>
                        </div>
                    </div>
                    <div class="form-options">
                        <label class="checkbox-label">
                            <input type="checkbox" name="remember"> Remember me
                        </label>
                        <a href="#" class="forgot-link">Forgot password?</a>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full">Sign In to Portal</button>
                </form>

                <div class="auth-hint">
                    <details>
                        <summary>Demo Credentials (Lab Environment)</summary>
                        <div class="hint-content">
                            <p><strong>Student:</strong> jsmith / Password1</p>
                            <p><strong>Teacher:</strong> prof_jones / Teacher1</p>
                            <p><strong>Admin:</strong> admin / admin123</p>
                            <!-- [VULNERABILITY: A07] Default credentials documented in UI -->
                        </div>
                    </details>
                </div>

                <p class="auth-footer-link">
                    Not a student? <a href="/admissions.php">Apply for Admission</a>
                </p>
            </div>
        </div>
    </div>

    <script>
    function togglePassword() {
        const pwd = document.getElementById('password');
        pwd.type = pwd.type === 'password' ? 'text' : 'password';
    }
    </script>
</body>
</html>
