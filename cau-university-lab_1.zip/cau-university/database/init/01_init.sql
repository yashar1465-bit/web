-- ============================================================
-- Code Academy University - Database Initialization
-- ============================================================

CREATE DATABASE IF NOT EXISTS university_db;
USE university_db;

-- ── Users Table ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    student_id  VARCHAR(20) UNIQUE NOT NULL,
    username    VARCHAR(100) NOT NULL,
    email       VARCHAR(255) UNIQUE NOT NULL,
    -- [VULNERABILITY: A07 - Identification and Authentication Failures]
    -- Passwords stored as MD5 (weak, unsalted hash)
    password    VARCHAR(255) NOT NULL,
    full_name   VARCHAR(255) NOT NULL,
    role        ENUM('student','teacher','admin') DEFAULT 'student',
    department  VARCHAR(100),
    year        INT,
    gpa         DECIMAL(3,2),
    bio         TEXT,
    -- [VULNERABILITY: A03 - XSS] bio field stored and rendered without sanitization
    profile_photo VARCHAR(255) DEFAULT 'default.png',
    phone       VARCHAR(20),
    address     TEXT,
    -- [VULNERABILITY: A01 - Broken Access Control] ssn stored, accessible via IDOR
    ssn         VARCHAR(20),
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── Courses Table ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS courses (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    code        VARCHAR(20) UNIQUE NOT NULL,
    name        VARCHAR(255) NOT NULL,
    description TEXT,
    credits     INT DEFAULT 3,
    teacher_id  INT,
    capacity    INT DEFAULT 30,
    enrolled    INT DEFAULT 0,
    semester    VARCHAR(20),
    schedule    VARCHAR(100),
    room        VARCHAR(50),
    FOREIGN KEY (teacher_id) REFERENCES users(id)
);

-- ── Enrollments Table ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS enrollments (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    student_id  INT NOT NULL,
    course_id   INT NOT NULL,
    grade       VARCHAR(5),
    grade_points DECIMAL(3,2),
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id),
    FOREIGN KEY (course_id)  REFERENCES courses(id)
);

-- ── Messages Table ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS messages (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    sender_id   INT NOT NULL,
    recipient_id INT,
    -- [VULNERABILITY: A03 - Stored XSS] subject and body stored without sanitization
    subject     VARCHAR(255),
    body        TEXT,
    is_public   BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id)   REFERENCES users(id),
    FOREIGN KEY (recipient_id) REFERENCES users(id)
);

-- ── Announcements Table ───────────────────────────────────
CREATE TABLE IF NOT EXISTS announcements (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(255) NOT NULL,
    content     TEXT NOT NULL,
    author_id   INT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── Contact Submissions ───────────────────────────────────
CREATE TABLE IF NOT EXISTS contact_submissions (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(255),
    email       VARCHAR(255),
    subject     VARCHAR(255),
    message     TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── Session Tokens ────────────────────────────────────────
-- [VULNERABILITY: A07] Sessions stored in DB with predictable tokens
CREATE TABLE IF NOT EXISTS sessions (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    token       VARCHAR(64) NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ============================================================
-- SEED DATA
-- ============================================================

-- [VULNERABILITY: A07 - Identification and Authentication Failures]
-- Default passwords: all students use "Password1", teachers use "Teacher1"
-- Stored as MD5 hashes (MD5('Password1') = 7c6a180b36896a0a8c02787eeafb0e4c)
-- MD5('Teacher1') = 9f4c38440f3d72b3d5ef7acec46a3c79
-- MD5('admin123') = 0192023a7bbd73250516f069df18b500

INSERT INTO users (student_id, username, email, password, full_name, role, department, year, gpa, bio, phone, address, ssn) VALUES
('STU001', 'jsmith',    'john.smith@students.cau.edu',    MD5('Password1'), 'John Smith',     'student', 'Computer Science',    3, 3.75, 'CS student interested in web development and AI.', '555-0101', '123 Oak Street, Campus Town, CT 06001', '123-45-6789'),
('STU002', 'ejohnson',  'emily.johnson@students.cau.edu', MD5('Password1'), 'Emily Johnson',  'student', 'Data Science',        2, 3.90, 'Data science enthusiast with a love for Python.', '555-0102', '456 Maple Ave, Campus Town, CT 06001', '234-56-7890'),
('STU003', 'mwilliams', 'mike.williams@students.cau.edu', MD5('Password1'), 'Mike Williams',  'student', 'Cybersecurity',       4, 3.20, 'Senior student focused on network security and pentesting.', '555-0103', '789 Pine Rd, Campus Town, CT 06001', '345-67-8901'),
('STU004', 'sbrown',    'sarah.brown@students.cau.edu',   MD5('Password1'), 'Sarah Brown',    'student', 'Software Engineering',1, 3.85, 'Freshman excited to learn software engineering.', '555-0104', '321 Elm St, Campus Town, CT 06002', '456-78-9012'),
('STU005', 'adavis',    'alex.davis@students.cau.edu',    MD5('Password1'), 'Alex Davis',     'student', 'Computer Science',    2, 2.95, 'Sophomore studying algorithms and system design.', '555-0105', '654 Cedar Blvd, Campus Town, CT 06002', '567-89-0123'),
('TCH001', 'prof_jones','prof.jones@faculty.cau.edu',     MD5('Teacher1'),  'Dr. Robert Jones','teacher','Computer Science',   NULL,NULL,'Professor of Computer Science with 15 years of experience.','555-0201','Faculty Building, Office 302', NULL),
('TCH002', 'prof_chen', 'prof.chen@faculty.cau.edu',      MD5('Teacher1'),  'Dr. Lisa Chen',  'teacher', 'Data Science',       NULL,NULL,'Associate Professor specializing in machine learning.', '555-0202', 'Faculty Building, Office 415', NULL),
('ADM001', 'admin',     'admin@cau.edu',                  MD5('admin123'),  'System Admin',   'admin',  'IT Department',       NULL,NULL,'University system administrator.', '555-0001', 'Admin Building, Room 101', NULL);

-- Courses
INSERT INTO courses (code, name, description, credits, teacher_id, capacity, enrolled, semester, schedule, room) VALUES
('CS101',  'Introduction to Programming',     'Fundamentals of programming using Python. Variables, loops, functions, and basic data structures.', 3, 6, 30, 18, 'Fall 2024', 'Mon/Wed 9:00-10:30', 'Tech Hall 201'),
('CS201',  'Data Structures & Algorithms',    'Advanced data structures including trees, graphs, heaps. Algorithm design and complexity analysis.', 4, 6, 25, 12, 'Fall 2024', 'Tue/Thu 11:00-12:30', 'Tech Hall 305'),
('CS301',  'Web Development',                 'Full-stack web development: HTML, CSS, JavaScript, PHP, and database integration.', 3, 6, 30, 22, 'Fall 2024', 'Mon/Wed/Fri 2:00-3:00', 'Tech Hall 201'),
('CS401',  'Network Security & Pentesting',   'Ethical hacking, vulnerability assessment, and network defense strategies.', 4, 6, 20, 8, 'Fall 2024', 'Tue/Thu 2:00-3:30', 'Security Lab 101'),
('DS201',  'Machine Learning Fundamentals',   'Supervised and unsupervised learning, neural networks, and model evaluation.', 4, 7, 25, 15, 'Fall 2024', 'Mon/Wed 11:00-12:30', 'Data Lab 202'),
('DS301',  'Big Data Analytics',              'Processing large datasets using Hadoop, Spark, and cloud platforms.', 3, 7, 20, 10, 'Fall 2024', 'Fri 9:00-12:00', 'Data Lab 301'),
('SE201',  'Software Engineering Principles', 'SDLC, agile methodologies, design patterns, and software testing.', 3, 6, 30, 25, 'Fall 2024', 'Tue/Thu 9:00-10:30', 'Tech Hall 102'),
('MATH201','Discrete Mathematics',            'Logic, sets, relations, graph theory, and combinatorics for CS students.', 3, 6, 35, 28, 'Fall 2024', 'Mon/Wed/Fri 10:00-11:00', 'Math Hall 101');

-- Enrollments & Grades
INSERT INTO enrollments (student_id, course_id, grade, grade_points) VALUES
(1, 1, 'A',  4.0), (1, 2, 'A-', 3.7), (1, 3, 'B+', 3.3), (1, 7, 'A', 4.0),
(2, 1, 'A',  4.0), (2, 5, 'A',  4.0), (2, 6, 'A-', 3.7), (2, 8, 'A', 4.0),
(3, 1, 'B',  3.0), (3, 4, 'A',  4.0), (3, 2, 'B+', 3.3), (3, 7, 'B', 3.0),
(4, 1, 'A',  4.0), (4, 7, 'A',  4.0), (4, 8, 'A',  4.0),
(5, 1, 'C+', 2.3), (5, 2, 'C',  2.0), (5, 3, 'B-', 2.7);

-- Messages (Public Board - contains XSS payload examples for the lab)
INSERT INTO messages (sender_id, recipient_id, subject, body, is_public) VALUES
(1, NULL, 'Study Group for CS201', 'Hey everyone! I am forming a study group for Data Structures. Meet in the library at 3pm on Thursday. Reply if interested!', TRUE),
(2, NULL, 'DS201 Project Partner Needed', 'Looking for a partner for the ML project. I have experience with scikit-learn. DM me!', TRUE),
(3, NULL, 'CS401 Lab Resources', 'Found some great resources for the pentesting lab. Check out the OWASP testing guide - very helpful for the assignments.', TRUE),
(4, NULL, 'New Student Introduction', 'Hi everyone! I am a freshman in Software Engineering. Looking forward to meeting you all and learning together!', TRUE);

-- Announcements
INSERT INTO announcements (title, content, author_id) VALUES
('Fall 2024 Registration Open',      'Course registration for Fall 2024 is now open. Log in to the student portal to register for your courses before August 15th.', 8),
('Campus Network Maintenance',       'The campus network will undergo maintenance on Saturday from 2:00 AM to 6:00 AM. Please plan accordingly.', 8),
('Dean''s List Announced',           'Congratulations to all students who made the Fall 2023 Dean''s List! Check the portal for the full list.', 8),
('Library Extended Hours',           'The university library will extend its hours during finals week: Mon-Fri 7am-2am, weekends 8am-midnight.', 8),
('New Cybersecurity Club Formed',    'A new student-led Cybersecurity Club has been formed. First meeting is Friday at 5pm in Tech Hall 101. All majors welcome!', 8);
