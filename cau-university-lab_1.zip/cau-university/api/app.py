"""
Code Academy University — Internal Student Data API
Flask Microservice

[VULNERABILITY: A04 - Insecure Design]
This entire API has NO authentication or authorization mechanism.
Every endpoint is publicly accessible — including those returning PII.

[VULNERABILITY: A05 - Security Misconfiguration]
- Flask debug mode enabled (Werkzeug interactive debugger)
- Verbose error messages with stack traces
- Database credentials in environment / exposed via /debug endpoint
- Bound to 0.0.0.0, exposed on host port 5000
"""

import os
import json
import traceback
import mysql.connector
from flask import Flask, jsonify, request, g

app = Flask(__name__)

# [VULNERABILITY: A05] Debug mode ON — exposes interactive Python debugger
app.config['DEBUG'] = True
app.config['PROPAGATE_EXCEPTIONS'] = False

# ── Database Connection ────────────────────────────────────────────────────────

DB_CONFIG = {
    'host':     os.environ.get('DB_HOST', 'db'),
    'database': os.environ.get('DB_NAME', 'university_db'),
    'user':     os.environ.get('DB_USER', 'root'),      # [VULNERABILITY: A05] Root user
    'password': os.environ.get('DB_PASS', 'root'),      # [VULNERABILITY: A05] Weak password
    'port':     3306,
}

def get_db():
    """Get database connection — reuse within request context."""
    if 'db' not in g:
        try:
            g.db = mysql.connector.connect(**DB_CONFIG)
        except mysql.connector.Error as e:
            # [VULNERABILITY: A04] Full error including connection details returned to client
            raise Exception(f"Database connection failed: {str(e)} | Config: {DB_CONFIG}")
    return g.db

@app.teardown_appcontext
def close_db(error):
    db = g.pop('db', None)
    if db is not None:
        db.close()

# ── Global Error Handler ───────────────────────────────────────────────────────

@app.errorhandler(Exception)
def handle_exception(e):
    """
    [VULNERABILITY: A04 - Insecure Design]
    Global error handler returns FULL stack trace and exception details to the client.
    Never do this in production — it leaks internal architecture, file paths, and DB info.
    """
    return jsonify({
        "error": str(e),
        "type": type(e).__name__,
        # [VULNERABILITY: A04] Full stack trace in API error response
        "traceback": traceback.format_exc(),
        "db_config": {k: v for k, v in DB_CONFIG.items() if k != 'password'},  # still leaks structure
        "note": "DEBUG MODE ACTIVE — This detail is only shown in development"
    }), 500

# ── Endpoints ──────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    """API root — lists all available endpoints (no auth required)."""
    return jsonify({
        "service": "Code Academy University — Student Data API",
        "version": "1.0.0",
        "environment": os.environ.get('FLASK_ENV', 'unknown'),
        # [VULNERABILITY: A04] Endpoint discovery with no authentication
        "endpoints": {
            "GET /students":            "List all students (PII included)",
            "GET /students/<id>":       "Get student by ID (SSN, address, etc.)",
            "GET /grades/<student_id>": "Get all grades for a student",
            "GET /users":               "All users including password hashes",
            "GET /courses":             "All courses",
            "GET /health":              "Service health check (DB credentials revealed)",
            "GET /debug":               "Debug info (environment variables exposed)",
            "GET /search":              "Search students — SQL injection vulnerable",
        }
    })


@app.route('/students', methods=['GET'])
def get_all_students():
    """
    [VULNERABILITY: A04 - Insecure Design]
    Returns ALL student records including PII to ANY caller — no authentication.
    Includes: full_name, email, phone, address, SSN, GPA, student_id
    """
    db     = get_db()
    cursor = db.cursor(dictionary=True)

    # [VULNERABILITY: A04] Returning SSN, address, phone — massively over-verbose
    cursor.execute("""
        SELECT id, student_id, full_name, email, phone, address,
               ssn, department, year, gpa, bio, role, created_at
        FROM users
        WHERE role = 'student'
        ORDER BY id
    """)
    students = cursor.fetchall()

    # Serialize datetime objects
    for s in students:
        if s.get('created_at'):
            s['created_at'] = str(s['created_at'])

    return jsonify({
        "count": len(students),
        "students": students,
        # [VULNERABILITY: A04] Auth status helpfully noted — always "none"
        "authentication": "none",
        "warning": "This endpoint requires no authentication — intentional lab vulnerability"
    })


@app.route('/students/<int:student_id>', methods=['GET'])
def get_student(student_id):
    """
    [VULNERABILITY: A01 + A04]
    Returns COMPLETE student record by ID — no auth, no ownership check.
    Includes SSN, full address, personal details.
    """
    db     = get_db()
    cursor = db.cursor(dictionary=True)

    # [VULNERABILITY: A04] All columns selected — including ssn, address, phone
    cursor.execute("SELECT * FROM users WHERE id = %s", (student_id,))
    student = cursor.fetchone()

    if not student:
        return jsonify({"error": "Student not found", "id": student_id}), 404

    # Remove password hash... but still return SSN and all PII
    student.pop('password', None)
    if student.get('created_at'):
        student['created_at'] = str(student['created_at'])

    return jsonify({
        "student": student,
        "data_classification": "PII — SSN and personal details included",
        "authentication_required": False  # [VULNERABILITY: A04]
    })


@app.route('/grades/<int:student_id>', methods=['GET'])
def get_grades(student_id):
    """
    [VULNERABILITY: A04] Returns full grade transcript for any student — no auth.
    """
    db     = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute("""
        SELECT e.id, e.grade, e.grade_points, e.enrolled_at,
               c.code, c.name AS course_name, c.credits, c.semester
        FROM enrollments e
        JOIN courses c ON e.course_id = c.id
        WHERE e.student_id = %s
        ORDER BY e.enrolled_at DESC
    """, (student_id,))
    grades = cursor.fetchall()

    for g in grades:
        if g.get('enrolled_at'):
            g['enrolled_at'] = str(g['enrolled_at'])

    # Also return the student info
    cursor.execute("SELECT id, full_name, student_id, gpa FROM users WHERE id = %s", (student_id,))
    student = cursor.fetchone()

    return jsonify({
        "student": student,
        "grades": grades,
        "count": len(grades)
    })


@app.route('/users', methods=['GET'])
def get_all_users():
    """
    [VULNERABILITY: A04 - Insecure Design] CRITICAL
    Returns ALL users INCLUDING their (MD5) password hashes — no authentication.
    An attacker can dump this and crack passwords offline.
    """
    db     = get_db()
    cursor = db.cursor(dictionary=True)

    # [VULNERABILITY: A04] Password hashes included in response
    cursor.execute("""
        SELECT id, student_id, username, email, password,
               full_name, role, department, ssn, phone, created_at
        FROM users
        ORDER BY role, id
    """)
    users = cursor.fetchall()

    for u in users:
        if u.get('created_at'):
            u['created_at'] = str(u['created_at'])

    return jsonify({
        "count": len(users),
        "users": users,
        # [VULNERABILITY: A04] Explicitly noting the password field
        "fields_note": "password field contains MD5 hash — crackable offline",
        "authentication": "none — this endpoint is intentionally unauthenticated for lab"
    })


@app.route('/courses', methods=['GET'])
def get_courses():
    db     = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        SELECT c.*, u.full_name AS teacher_name, u.email AS teacher_email
        FROM courses c LEFT JOIN users u ON c.teacher_id = u.id
        ORDER BY c.code
    """)
    courses = cursor.fetchall()
    return jsonify({"count": len(courses), "courses": courses})


@app.route('/search', methods=['GET'])
def search_students():
    """
    [VULNERABILITY: A03 - SQL Injection]
    The 'name' query parameter is directly interpolated into SQL — no sanitization.
    Exploit: GET /search?name=' UNION SELECT 1,username,password,email,ssn,6,7,8,9,10,11,12,13 FROM users --
    """
    name = request.args.get('name', '')
    dept = request.args.get('dept', '')

    db     = get_db()
    cursor = db.cursor(dictionary=True)

    # [VULNERABILITY: A03 - SQL Injection] Raw string formatting — not parameterized
    query = f"""
        SELECT id, student_id, full_name, email, department, year, gpa
        FROM users
        WHERE role = 'student'
          AND full_name LIKE '%{name}%'
          AND department LIKE '%{dept}%'
    """

    try:
        cursor.execute(query)
        results = cursor.fetchall()
        return jsonify({
            "query": {"name": name, "dept": dept},
            "count": len(results),
            "results": results,
            # [VULNERABILITY: A04] Raw SQL query returned in response for "debugging"
            "debug_query": query
        })
    except Exception as e:
        # [VULNERABILITY: A04] Full SQL error including query returned
        return jsonify({
            "error": str(e),
            "failed_query": query,
            "hint": "SQL error — check your syntax"
        }), 400


@app.route('/health', methods=['GET'])
def health_check():
    """
    [VULNERABILITY: A04 + A05]
    Health check endpoint reveals internal network topology and DB connection details.
    """
    try:
        db     = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT VERSION()")
        db_version = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM users")
        user_count = cursor.fetchone()[0]
        db_status = "connected"
    except Exception as e:
        db_version = None
        user_count = None
        db_status  = f"error: {str(e)}"  # [VULNERABILITY: A04] Error details exposed

    return jsonify({
        "status": "healthy",
        "service": "University Student API",
        # [VULNERABILITY: A05] Internal network details exposed
        "database": {
            "host":    DB_CONFIG['host'],
            "name":    DB_CONFIG['database'],
            "user":    DB_CONFIG['user'],          # [VULNERABILITY: A05] DB username exposed
            "version": db_version,
            "status":  db_status,
            "records": user_count
        },
        "environment": {
            "flask_env":   os.environ.get('FLASK_ENV'),
            "flask_debug": os.environ.get('FLASK_DEBUG'),
            "python_path": os.environ.get('PYTHONPATH'),
        }
    })


@app.route('/debug', methods=['GET'])
def debug_info():
    """
    [VULNERABILITY: A04 + A05] CRITICAL
    Debug endpoint dumps ALL environment variables — including secrets and credentials.
    Left enabled "for development convenience."
    """
    # [VULNERABILITY: A05] ALL environment variables exposed — includes DB_PASS, secrets
    env_vars = dict(os.environ)

    return jsonify({
        "warning": "DEBUG ENDPOINT — REMOVE BEFORE PRODUCTION",
        # [VULNERABILITY: A05] Full environment dump including DB_PASS
        "environment_variables": env_vars,
        "working_directory": os.getcwd(),
        "python_version": os.sys.version,
        "files_in_cwd": os.listdir('.'),
    })


if __name__ == '__main__':
    # [VULNERABILITY: A05] Debug mode, all interfaces
    app.run(host='0.0.0.0', port=5000, debug=True)
